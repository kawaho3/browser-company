// Copyright 2026 The OpenSandbox Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package credentialvault

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net"
	"net/http"
	"net/url"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"golang.org/x/net/http/httpguts"

	"github.com/alibaba/opensandbox/egress/pkg/constants"
)

// Egress → credential header resolver client (OSEP-0025 frozen contract).
// The envelope is untrusted input (D14): over-limit responses are per-request
// denials, never global faults.

const (
	// D14 envelope caps.
	maxResolverResponseBytes  = 64 << 10
	maxResolverHeaderCount    = 16
	maxResolverValueBytes     = 8 << 10
	maxResolverRedactionCount = 64
	// Caps the HTTP response header block itself, not the JSON body.
	maxResolverResponseHeaderBytes = 8 << 10
)

// ResolverErrorKind classifies a failed resolve; all kinds are per-request
// outcomes and fail closed.
type ResolverErrorKind string

const (
	ResolverInvalidRequest  ResolverErrorKind = "invalid_request"
	ResolverUnavailable     ResolverErrorKind = "unavailable"
	ResolverTimeout         ResolverErrorKind = "timeout"
	ResolverRejected        ResolverErrorKind = "rejected"         // non-200
	ResolverInvalidResponse ResolverErrorKind = "invalid_response" // 200, bad envelope
	ResolverDenied          ResolverErrorKind = "denied"           // D14/R14
)

// ResolverError is the typed failure of one resolve call.
type ResolverError struct {
	Kind   ResolverErrorKind
	Reason string
	Status int
	err    error
}

func (e *ResolverError) Error() string {
	var b strings.Builder
	fmt.Fprintf(&b, "resolver %s", e.Kind)
	if e.Reason != "" {
		fmt.Fprintf(&b, " (%s)", e.Reason)
	}
	if e.Status != 0 {
		fmt.Fprintf(&b, " status=%d", e.Status)
	}
	return b.String()
}

func (e *ResolverError) Unwrap() error { return e.err }

func resolverErrorf(kind ResolverErrorKind, reason string) *ResolverError {
	return &ResolverError{Kind: kind, Reason: reason}
}

// ResolverClient resolves one exchange's credential headers.
type ResolverClient interface {
	Resolve(ctx context.Context, input ResolveInput) (*ResolverDecision, error)
}

// ResolveInput is one resolution request (frozen contract request document).
type ResolveInput struct {
	// Subject is the egress-authoritative sandboxId.
	Subject string
	// Credential and Binding name the vault credential and binding.
	Credential string
	Binding    string
	// Destination is the intercepted target origin.
	Destination ResolveDestination
	// Request is the outbound frame the headers apply to.
	Request ResolveRequestFrame
}

// ResolveDestination identifies the intercepted origin.
type ResolveDestination struct {
	Scheme    string // "http" or "https"
	Authority string // host:port of the origin
	SNI       string // TLS server name (authority host for https)
}

// ResolveRequestFrame describes the outbound request.
type ResolveRequestFrame struct {
	Method  string
	Host    string
	Path    string // starts with "/"
	Headers map[string]string
}

// ResolverDecision is the validated outcome: headers to inject, names to
// suppress, and merged redactions (derived variants authoritative; resolver
// redactions incremental only, R9).
type ResolverDecision struct {
	Headers    map[string]string
	Suppress   map[string]struct{} // lowercase header names
	Redactions []string            // canonically ordered, deduped, non-empty
}

// ResolverClientOptions constructs one client.
type ResolverClientOptions struct {
	// Endpoint is "uds:///absolute/socket/path", "unix://..." (alias), or
	// "https://host[:port][/prefix]".
	Endpoint string
	// Timeout bounds every resolve call; 0 selects the default.
	Timeout time.Duration
	// MaxConcurrency bounds in-flight resolves; 0 selects the default.
	MaxConcurrency int
	// TLSClientConfig overrides HTTPS TLS (test/deployment seam); nil keeps
	// system verification.
	TLSClientConfig *tls.Config
}

// NewResolverClient validates the endpoint; no connection is dialed.
func NewResolverClient(options ResolverClientOptions) (ResolverClient, error) {
	if options.Timeout <= 0 {
		options.Timeout = ResolverTimeoutFromEnv()
	}
	if options.Timeout <= 0 {
		return nil, resolverErrorf(ResolverInvalidRequest, "timeout_must_be_positive")
	}
	if options.MaxConcurrency <= 0 {
		options.MaxConcurrency = ResolverMaxConcurrencyFromEnv()
	}
	if options.MaxConcurrency <= 0 {
		return nil, resolverErrorf(ResolverInvalidRequest, "max_concurrency_must_be_positive")
	}
	parsed, err := parseResolverEndpoint(options.Endpoint)
	if err != nil {
		return nil, err
	}

	client := &resolverClient{
		timeout:     options.Timeout,
		concurrency: make(chan struct{}, options.MaxConcurrency),
	}
	httpClient := &http.Client{
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}

	var transport *http.Transport
	if parsed.network == "unix" {
		socketPath := parsed.socketPath
		dialer := &net.Dialer{}
		transport = &http.Transport{
			DisableKeepAlives:      true,
			MaxResponseHeaderBytes: maxResolverResponseHeaderBytes,
			DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
				return dialer.DialContext(ctx, "unix", socketPath)
			},
		}
		client.requestURL = (&url.URL{Scheme: "http", Host: "localhost", Path: parsed.resolvePath}).String()
	} else {
		if parsed.authority == "" {
			return nil, resolverErrorf(ResolverInvalidRequest, "missing_https_origin")
		}
		// Proxy stays nil: resolver dials never traverse an outbound proxy.
		transport = &http.Transport{
			DisableKeepAlives:      true,
			ForceAttemptHTTP2:      false,
			MaxResponseHeaderBytes: maxResolverResponseHeaderBytes,
			TLSClientConfig:        options.TLSClientConfig,
		}
		client.requestURL = (&url.URL{Scheme: "https", Host: parsed.authority, Path: parsed.resolvePath}).String()
		client.hostHeader = parsed.authority
	}
	httpClient.Transport = transport
	client.http = httpClient
	return client, nil
}

type parsedResolverEndpoint struct {
	network     string // "unix" or "tcp"
	socketPath  string // unix only
	authority   string // https host[:port] as configured
	resolvePath string // request target: prefix + "/resolve"
}

// parseResolverEndpoint derives the D15 framing: https targets are
// prefix + "/resolve"; unix endpoints carry no prefix.
func parseResolverEndpoint(endpoint string) (*parsedResolverEndpoint, error) {
	raw, err := url.Parse(strings.TrimSpace(endpoint))
	if err != nil {
		return nil, fmt.Errorf("invalid resolver endpoint %q: %w", endpoint, err)
	}
	switch strings.ToLower(raw.Scheme) {
	case "uds", "unix":
		if raw.Host != "" {
			return nil, resolverErrorf(ResolverInvalidRequest, "uds_endpoint_requires_empty_authority")
		}
		if !filepath.IsAbs(raw.Path) {
			return nil, resolverErrorf(ResolverInvalidRequest, "uds_endpoint_requires_absolute_path")
		}
		return &parsedResolverEndpoint{
			network:     "unix",
			socketPath:  filepath.Clean(raw.Path),
			resolvePath: "/resolve",
		}, nil
	case "https":
		if raw.Host == "" {
			return nil, resolverErrorf(ResolverInvalidRequest, "https_endpoint_requires_authority")
		}
		if raw.RawQuery != "" || raw.Fragment != "" || raw.User != nil {
			return nil, resolverErrorf(ResolverInvalidRequest, "https_endpoint_rejects_query_fragment_userinfo")
		}
		prefix := raw.Path
		if prefix == "/" {
			prefix = ""
		}
		if prefix != "" && (!strings.HasPrefix(prefix, "/") || strings.HasSuffix(prefix, "/")) {
			return nil, resolverErrorf(ResolverInvalidRequest, "https_endpoint_prefix_must_be_a_non_trailing_slash_path")
		}
		return &parsedResolverEndpoint{
			network:     "tcp",
			authority:   raw.Host,
			resolvePath: prefix + "/resolve",
		}, nil
	default:
		return nil, resolverErrorf(ResolverInvalidRequest, "unsupported_endpoint_scheme")
	}
}

// ResolverTimeoutFromEnv reads the timeout env (seconds); bad values keep
// the default.
func ResolverTimeoutFromEnv() time.Duration {
	seconds := constants.EnvIntRange(
		constants.EnvCredentialResolverTimeout,
		constants.DefaultCredentialResolverTimeoutSeconds,
		1, 120,
	)
	return time.Duration(seconds) * time.Second
}

// ResolverMaxConcurrencyFromEnv reads the concurrency env; bad values keep
// the default.
func ResolverMaxConcurrencyFromEnv() int {
	return constants.EnvIntRange(
		constants.EnvCredentialResolverMaxConcurrency,
		constants.DefaultCredentialResolverMaxConcurrency,
		1, 1024,
	)
}

// NewResolverClientFromEnv builds a client from the resolver envs; wiring
// supplies the endpoint.
func NewResolverClientFromEnv(endpoint string) (ResolverClient, error) {
	return NewResolverClient(ResolverClientOptions{Endpoint: endpoint})
}

// resolverClient is the UDS/HTTPS transport; construct via NewResolverClient.
type resolverClient struct {
	http        *http.Client
	requestURL  string
	hostHeader  string // https: endpoint authority; empty for unix (localhost)
	timeout     time.Duration
	concurrency chan struct{}
}

var _ ResolverClient = (*resolverClient)(nil)

// Resolve performs one resolution; failures are typed ResolverError values.
func (c *resolverClient) Resolve(ctx context.Context, input ResolveInput) (*ResolverDecision, error) {
	if err := ctx.Err(); err != nil {
		return nil, &ResolverError{Kind: ResolverTimeout, err: err}
	}
	document, err := marshalResolveInput(input)
	if err != nil {
		return nil, err
	}

	// The deadline bounds the whole call — queueing included — so queued
	// resolves cannot stack one timeout per pending batch.
	callCtx, cancel := context.WithTimeout(ctx, c.timeout)
	defer cancel()
	select {
	case c.concurrency <- struct{}{}:
		defer func() { <-c.concurrency }()
	case <-callCtx.Done():
		return nil, &ResolverError{Kind: ResolverTimeout, err: callCtx.Err()}
	}

	request, err := http.NewRequestWithContext(callCtx, http.MethodPost, c.requestURL, bytes.NewReader(document))
	if err != nil {
		return nil, resolverErrorf(ResolverInvalidRequest, "request_build_failed")
	}
	request.Header.Set("Content-Type", "application/json")
	if c.hostHeader != "" {
		// D15: Host is the endpoint authority (localhost over unix).
		request.Host = c.hostHeader
	}
	request.Close = true

	response, err := c.http.Do(request)
	if err != nil {
		if callCtx.Err() != nil {
			return nil, &ResolverError{Kind: ResolverTimeout, err: callCtx.Err()}
		}
		return nil, &ResolverError{Kind: ResolverUnavailable, err: err}
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		// Drain a little so the peer cannot stream unbounded bytes.
		_, _ = io.Copy(io.Discard, io.LimitReader(response.Body, maxResolverResponseHeaderBytes))
		return nil, &ResolverError{Kind: ResolverRejected, Status: response.StatusCode}
	}
	if mediaType, _, err := mime.ParseMediaType(response.Header.Get("Content-Type")); err != nil || mediaType != "application/json" {
		return nil, resolverErrorf(ResolverInvalidResponse, "content_type_not_json")
	}

	data, err := io.ReadAll(io.LimitReader(response.Body, maxResolverResponseBytes+1))
	if err != nil {
		// A body trickling past the deadline is a timeout, not unavailability.
		if callCtx.Err() != nil {
			return nil, &ResolverError{Kind: ResolverTimeout, err: callCtx.Err()}
		}
		return nil, &ResolverError{Kind: ResolverUnavailable, err: err}
	}
	if len(data) > maxResolverResponseBytes {
		return nil, resolverErrorf(ResolverDenied, "response_too_large")
	}
	envelope, err := decodeResolveResponse(data)
	if err != nil {
		return nil, err
	}
	return deriveResolverDecision(envelope.headers, envelope.redactions), nil
}

// marshalResolveInput validates the request contract and encodes the exact
// wire document.
func marshalResolveInput(input ResolveInput) ([]byte, error) {
	nonEmpty := func(value string) bool { return value != "" }
	switch {
	case !nonEmpty(input.Subject), !nonEmpty(input.Credential), !nonEmpty(input.Binding):
		return nil, resolverErrorf(ResolverInvalidRequest, "subject_credential_binding_required")
	case input.Destination.Scheme != "http" && input.Destination.Scheme != "https":
		return nil, resolverErrorf(ResolverInvalidRequest, "destination_scheme_invalid")
	case !nonEmpty(input.Destination.Authority), !nonEmpty(input.Destination.SNI):
		return nil, resolverErrorf(ResolverInvalidRequest, "destination_authority_sni_required")
	case !nonEmpty(input.Request.Method), !nonEmpty(input.Request.Host):
		return nil, resolverErrorf(ResolverInvalidRequest, "request_method_host_required")
	case !strings.HasPrefix(input.Request.Path, "/"):
		return nil, resolverErrorf(ResolverInvalidRequest, "request_path_must_start_with_slash")
	}
	for name, value := range input.Request.Headers {
		if !nonEmpty(name) || !nonEmpty(value) {
			return nil, resolverErrorf(ResolverInvalidRequest, "request_headers_must_be_non_empty_strings")
		}
	}
	requestHeaders := input.Request.Headers
	if requestHeaders == nil {
		// D15: request.headers must be a JSON object; a nil Go map would
		// serialize as null.
		requestHeaders = map[string]string{}
	}
	document := resolveRequestDocument{
		Subject:    input.Subject,
		Credential: input.Credential,
		Binding:    input.Binding,
		Destination: resolveDestinationDocument{
			Scheme:    input.Destination.Scheme,
			Authority: input.Destination.Authority,
			SNI:       input.Destination.SNI,
		},
		Request: resolveRequestFrameDocument{
			Method:  input.Request.Method,
			Host:    input.Request.Host,
			Path:    input.Request.Path,
			Headers: requestHeaders,
		},
	}
	encoded, err := json.Marshal(document)
	if err != nil {
		return nil, resolverErrorf(ResolverInvalidRequest, "request_encode_failed")
	}
	if len(encoded) > maxResolverResponseBytes {
		return nil, resolverErrorf(ResolverInvalidRequest, "request_too_large")
	}
	return encoded, nil
}

type resolveRequestDocument struct {
	Subject     string                      `json:"subject"`
	Credential  string                      `json:"credential"`
	Binding     string                      `json:"binding"`
	Destination resolveDestinationDocument  `json:"destination"`
	Request     resolveRequestFrameDocument `json:"request"`
}

type resolveDestinationDocument struct {
	Scheme    string `json:"scheme"`
	Authority string `json:"authority"`
	SNI       string `json:"sni"`
}

type resolveRequestFrameDocument struct {
	Method  string            `json:"method"`
	Host    string            `json:"host"`
	Path    string            `json:"path"`
	Headers map[string]string `json:"headers"`
}

// decodeResolveResponse strictly decodes the envelope: exact fields only,
// no duplicates/nulls/trailing data. Limits are ResolverDenied; schema
// violations are ResolverInvalidResponse.
func decodeResolveResponse(data []byte) (*resolveResponseDocument, error) {
	fields, err := strictJSONObject(data)
	if err != nil {
		return nil, resolverErrorf(ResolverInvalidResponse, "malformed_json")
	}
	for name := range fields {
		if name != "headers" && name != "redactions" {
			return nil, resolverErrorf(ResolverInvalidResponse, "unknown_field")
		}
	}
	headersRaw, ok := fields["headers"]
	if !ok {
		return nil, resolverErrorf(ResolverInvalidResponse, "headers_field_required")
	}
	if len(headersRaw) > maxResolverResponseBytes {
		return nil, resolverErrorf(ResolverDenied, "response_too_large")
	}
	document := &resolveResponseDocument{}
	if document.headers, err = decodeHeaderMap(headersRaw); err != nil {
		return nil, err
	}
	if redactionsRaw, ok := fields["redactions"]; ok {
		if document.redactions, err = decodeRedactionMap(redactionsRaw); err != nil {
			return nil, err
		}
	}
	return document, nil
}

type resolveResponseDocument struct {
	headers    map[string]string
	redactions map[string][]string
}

// decodeHeaderMap enforces the credential-header rules: token-pattern names
// off the reserved/hop-by-hop blacklist, non-empty values within the caps.
func decodeHeaderMap(raw json.RawMessage) (map[string]string, error) {
	fields, err := strictJSONObject(raw)
	if err != nil {
		return nil, resolverErrorf(ResolverInvalidResponse, "headers_not_object")
	}
	if len(fields) > maxResolverHeaderCount {
		return nil, resolverErrorf(ResolverDenied, "too_many_headers")
	}
	headers := make(map[string]string, len(fields))
	seenNames := make(map[string]struct{}, len(fields))
	for name, valueRaw := range fields {
		// Header names are case-insensitive; byte-different keys naming one
		// header are one header, not two.
		lowerName := strings.ToLower(name)
		if _, duplicate := seenNames[lowerName]; duplicate {
			return nil, resolverErrorf(ResolverInvalidResponse, "duplicate_header_name")
		}
		seenNames[lowerName] = struct{}{}
		if len(name) > maxResolverValueBytes {
			return nil, resolverErrorf(ResolverDenied, "header_name_too_long")
		}
		if validateCredentialHeaderName(name) != nil {
			return nil, resolverErrorf(ResolverDenied, "denied_header_name")
		}
		value, err := decodeNonEmptyString(valueRaw, "header_value_too_long")
		if err != nil {
			return nil, err
		}
		// Values land in outbound HTTP frames; reject illegal field-values.
		if !httpguts.ValidHeaderFieldValue(value) {
			return nil, resolverErrorf(ResolverDenied, "denied_header_value")
		}
		headers[name] = value
	}
	return headers, nil
}

// decodeRedactionMap validates resolver-provided incremental redactions (R9).
func decodeRedactionMap(raw json.RawMessage) (map[string][]string, error) {
	fields, err := strictJSONObject(raw)
	if err != nil {
		return nil, resolverErrorf(ResolverInvalidResponse, "redactions_not_object")
	}
	redactions := make(map[string][]string, len(fields))
	total := 0
	for name, valuesRaw := range fields {
		values, err := decodeNonEmptyStringArray(valuesRaw)
		if err != nil {
			return nil, err
		}
		total += len(values)
		if total > maxResolverRedactionCount {
			return nil, resolverErrorf(ResolverDenied, "too_many_redactions")
		}
		for _, value := range values {
			if len(value) > maxResolverValueBytes {
				return nil, resolverErrorf(ResolverDenied, "redaction_value_too_long")
			}
		}
		redactions[name] = values
	}
	return redactions, nil
}

func decodeNonEmptyString(raw json.RawMessage, tooLongReason string) (string, error) {
	if trimmed := bytes.TrimSpace(raw); len(trimmed) == 0 || trimmed[0] != '"' {
		return "", resolverErrorf(ResolverInvalidResponse, "value_not_string")
	}
	var value string
	if err := json.Unmarshal(raw, &value); err != nil {
		return "", resolverErrorf(ResolverInvalidResponse, "value_not_string")
	}
	if value == "" {
		// Schema violation, not a limit.
		return "", resolverErrorf(ResolverInvalidResponse, "empty_value")
	}
	if len(value) > maxResolverValueBytes {
		return "", resolverErrorf(ResolverDenied, tooLongReason)
	}
	return value, nil
}

func decodeNonEmptyStringArray(raw json.RawMessage) ([]string, error) {
	trimmed := bytes.TrimSpace(raw)
	if len(trimmed) == 0 || trimmed[0] != '[' {
		return nil, resolverErrorf(ResolverInvalidResponse, "redaction_values_not_array")
	}
	var values []string
	if err := json.Unmarshal(raw, &values); err != nil {
		return nil, resolverErrorf(ResolverInvalidResponse, "redaction_values_not_strings")
	}
	if len(values) == 0 {
		return nil, resolverErrorf(ResolverInvalidResponse, "redaction_values_empty")
	}
	for _, value := range values {
		if value == "" {
			return nil, resolverErrorf(ResolverInvalidResponse, "redaction_values_not_strings")
		}
		if len(value) > maxResolverValueBytes {
			return nil, resolverErrorf(ResolverDenied, "redaction_value_too_long")
		}
	}
	return values, nil
}

// strictJSONObject decodes one JSON object with unique keys; rejects
// non-objects and trailing bytes.
func strictJSONObject(data []byte) (map[string]json.RawMessage, error) {
	decoder := json.NewDecoder(bytes.NewReader(data))
	token, err := decoder.Token()
	if err != nil {
		return nil, err
	}
	if delim, ok := token.(json.Delim); !ok || delim != '{' {
		return nil, errors.New("not an object")
	}
	fields := make(map[string]json.RawMessage)
	for decoder.More() {
		token, err = decoder.Token()
		if err != nil {
			return nil, err
		}
		name, ok := token.(string)
		if !ok {
			return nil, errors.New("non-string object key")
		}
		if _, duplicate := fields[name]; duplicate {
			return nil, fmt.Errorf("duplicate key %q", name)
		}
		var raw json.RawMessage
		if err := decoder.Decode(&raw); err != nil {
			return nil, err
		}
		fields[name] = raw
	}
	if token, err = decoder.Token(); err != nil {
		return nil, err
	}
	if delim, ok := token.(json.Delim); !ok || delim != '}' {
		return nil, errors.New("unterminated object")
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return nil, errors.New("trailing data")
	}
	return fields, nil
}

// canonicalResolverRedactions dedups and orders values longest-first with
// ascending byte tie-break (decision-snapshot canonical form).
func canonicalResolverRedactions(values []string) []string {
	seen := make(map[string]struct{}, len(values))
	merged := make([]string, 0, len(values))
	for _, value := range values {
		if value == "" {
			continue
		}
		if _, exists := seen[value]; exists {
			continue
		}
		seen[value] = struct{}{}
		merged = append(merged, value)
	}
	sort.Slice(merged, func(i, j int) bool {
		if len(merged[i]) != len(merged[j]) {
			return len(merged[i]) > len(merged[j])
		}
		return merged[i] < merged[j]
	})
	return merged
}
