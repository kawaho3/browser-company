// Copyright 2026 The OpenSandbox Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package fastsandboxnft

import (
	"context"
	"errors"
	"fmt"
	"net/netip"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/alibaba/opensandbox/egress/pkg/actionhandler"
	"github.com/alibaba/opensandbox/egress/pkg/nftables"
	"github.com/alibaba/opensandbox/egress/pkg/policy"
	"github.com/alibaba/opensandbox/egress/pkg/subject"
)

// fakeRunner records every script and optionally fails.
type fakeRunner struct {
	mu      sync.Mutex
	scripts []string
	fail    func(script string) error
}

func (r *fakeRunner) Run(_ context.Context, script string) ([]byte, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.scripts = append(r.scripts, script)
	if r.fail != nil {
		return nil, r.fail(script)
	}
	return nil, nil
}

func (r *fakeRunner) count() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.scripts)
}

func (r *fakeRunner) last() string {
	r.mu.Lock()
	defer r.mu.Unlock()
	if len(r.scripts) == 0 {
		return ""
	}
	return r.scripts[len(r.scripts)-1]
}

func testSlot(uid string, ip string) actionhandler.NetworkAttachment {
	return actionhandler.NetworkAttachment{
		IP:          netip.MustParseAddr(ip),
		Gateway:     netip.MustParseAddr("10.0.0.1"),
		PrivateCIDR: netip.MustParsePrefix("10.0.0.0/24"),
		HostVeth:    "veth" + uid,
	}
}

func TestDenyFirstInstallFailClosedShape(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()

	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	script := runner.last()

	// master chain is fail-closed: ACCEPT policy with an unmarked-drop tail
	// (the forward path never issues an explicit accept — bridge-netfilter
	// semantics), plus the prerouting mark hook chain
	require.Contains(t, script, "add chain inet opensandbox-fast-sandbox dispatch { type filter hook forward priority 0; policy accept; }")
	require.Contains(t, script, "add chain inet opensandbox-fast-sandbox marking { type filter hook prerouting priority 0; }")
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch meta mark & 0x2 != 0x2 drop")
	// dispatch rule binds source IP + host veth (defense in depth)
	require.Contains(t, script, "ip saddr 10.0.0.5 jump")
	require.Contains(t, script, `add rule inet opensandbox-fast-sandbox dispatch ip saddr 10.0.0.5 jump subj_s_u_1`)
	// the prerouting mark jump reaches the subject's mark chain
	require.Contains(t, script, `add rule inet opensandbox-fast-sandbox marking ip saddr 10.0.0.5 jump mark_s_u_1`)
	// subject chains exist; deny-first = no mark rules, drop-only forward chain
	require.Contains(t, script, "subj_s_u_1")
	require.Contains(t, script, "mark_s_u_1")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 drop")
	assert.NotContains(t, script, "meta mark set", "deny-first must not mark anything")
	// no allow elements exist yet
	require.NotContains(t, script, "add element inet opensandbox-fast-sandbox subj_s_u_1_allow")

	// second subject: table header must NOT be re-created (would kill subject 1)
	s2 := subject.FromSandboxUID("u-2")
	require.NoError(t, a.ApplyDenyFirst(ctx, s2, testSlot("u-2", "10.0.0.6")))
	script2 := runner.last()
	assert.NotContains(t, script2, "delete table inet opensandbox-fast-sandbox", "table must not be recreated")
	require.Contains(t, script2, `add rule inet opensandbox-fast-sandbox dispatch ip saddr 10.0.0.6 jump subj_s_u_2`)
	require.Equal(t, 2, runner.count())
}

func TestPolicySwapAtomic(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()

	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()

	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"10.0.0.0/24"},{"action":"deny","target":"1.2.3.4"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))

	script := runner.last()
	// swap = flush chain + flush static sets + re-add elements/rules, ONE transaction
	require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox subj_s_u_1")
	require.Contains(t, script, "flush set inet opensandbox-fast-sandbox subj_s_u_1_allow_v4")
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox subj_s_u_1_allow_v4 { 10.0.0.0/24 }")
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox subj_s_u_1_deny_v4 { 1.2.3.4 }")
	// dynamic sets survive the swap (never deleted)
	assert.NotContains(t, script, "flush set inet opensandbox-fast-sandbox subj_s_u_1_dyn")
	require.Equal(t, 1, runner.count(), "policy swap must be a single transaction")
}

func TestPolicySwapFailureKeepsState(t *testing.T) {
	var swapAttempts atomic.Int32
	runner := &fakeRunner{fail: func(script string) error {
		if strings.Contains(script, "flush chain") && swapAttempts.Add(1) == 1 {
			return context.DeadlineExceeded
		}
		return nil
	}}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny"}`)
	require.NoError(t, err)
	require.Error(t, a.ApplyPolicy(ctx, s, pol))

	// state unchanged: a retry must produce the same swap script (idempotent)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	require.Equal(t, int32(2), swapAttempts.Load(), "first swap fails, retry succeeds")
}

func TestUnknownSubjectRejected(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny"}`)
	require.NoError(t, err)
	require.ErrorIs(t, a.ApplyPolicy(ctx, subject.FromSandboxUID("ghost"), pol), ErrUnknownSubject)
	require.ErrorIs(t, a.AddResolvedIPs(ctx, subject.FromSandboxUID("ghost"), "example.com", []nftables.ResolvedIP{{Addr: netip.MustParseAddr("1.2.3.4"), TTL: time.Minute}}), ErrUnknownSubject)
}

func TestAddResolvedIPsClampsTTL(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"example.com"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	require.NoError(t, a.AddResolvedIPs(ctx, s, "example.com", []nftables.ResolvedIP{
		{Addr: netip.MustParseAddr("1.2.3.4"), TTL: 30 * time.Second},   // clamps up to 90s (min 60 + slack)
		{Addr: netip.MustParseAddr("2001:db8::1"), TTL: 24 * time.Hour}, // clamps down to 360s
	}))
	script := runner.last()
	require.Contains(t, script, "1.2.3.4 timeout 90s")
	require.Contains(t, script, "2001:db8::1 timeout 360s")
}

func TestAddResolvedIPsRecreatesElementsToRenewExpiry(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"example.com"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	require.NoError(t, a.AddResolvedIPs(ctx, s, "example.com", []nftables.ResolvedIP{
		{Addr: netip.MustParseAddr("1.2.3.4"), TTL: 300 * time.Second},
		{Addr: netip.MustParseAddr("2001:db8::1"), TTL: 300 * time.Second},
	}))
	script := runner.last()
	for _, tc := range []struct{ set, addr string }{
		{dynSetName(s, "v4"), "1.2.3.4"},
		{dynSetName(s, "v6"), "2001:db8::1"},
	} {
		require.Contains(t, script, fmt.Sprintf(
			"add element inet %[1]s %[2]s { %[3]s }\ndelete element inet %[1]s %[2]s { %[3]s }\nadd element inet %[1]s %[2]s { %[3]s timeout 360s }\n",
			TableName, tc.set, tc.addr), "a plain add does not renew an existing element's kernel expiry")
	}
}

// TestAddResolvedIPsRejectsDomainRevokedByReload: a DNS answer that was in
// flight while an always-rule reload tightened the overlay must not
// re-authorize the revoked domain's cached IP.
func TestAddResolvedIPsRejectsDomainRevokedByReload(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"example.com"},{"action":"allow","target":"api.example.com"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	ips := []nftables.ResolvedIP{{Addr: netip.MustParseAddr("192.0.2.1"), TTL: 0}}
	require.NoError(t, a.AddResolvedIPs(ctx, s, "example.com", ips))

	// the overlay tightens: example.com moves to always-deny
	denyRule, err := policy.ParseValidatedEgressRule("deny", "example.com")
	require.NoError(t, err)
	merged := policy.MergeAlwaysOverlay(pol, []policy.EgressRule{denyRule}, nil)
	require.NoError(t, a.ApplyAlwaysRulesReload(ctx, nil, map[subject.Subject]*policy.NetworkPolicy{s: merged}))

	// the stale in-flight answer arrives after the reload: refused
	count := runner.count()
	require.ErrorIs(t, a.AddResolvedIPs(ctx, s, "example.com", ips), ErrLeaseRejected)
	require.Equal(t, count, runner.count(), "a refused lease must not emit an nft transaction")
	require.NotContains(t, runner.last(), "192.0.2.1")
	a.mu.Lock()
	_, tracked := a.states[s]
	a.mu.Unlock()
	require.False(t, tracked, "a refused lease must not enter the refresh mirror")

	// a domain the reload still allows keeps working
	require.NoError(t, a.AddResolvedIPs(ctx, s, "api.example.com", ips))
	require.Contains(t, runner.last(), "192.0.2.1")
}

// TestAddResolvedIPsRejectsDenyFirstSubject: a subject that reverted to
// deny-first while its DNS answer was in flight must not re-acquire a lease.
func TestAddResolvedIPsRejectsDenyFirstSubject(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	count := runner.count()
	require.ErrorIs(t, a.AddResolvedIPs(ctx, s, "example.com", []nftables.ResolvedIP{{Addr: netip.MustParseAddr("192.0.2.1"), TTL: 0}}), ErrLeaseRejected)
	require.Equal(t, count, runner.count(), "a refused lease must not emit an nft transaction")
	a.mu.Lock()
	_, tracked := a.states[s]
	a.mu.Unlock()
	require.False(t, tracked)
}

func TestRemoveRebuildsTable(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	s1 := subject.FromSandboxUID("u-1")
	s2 := subject.FromSandboxUID("u-2")
	require.NoError(t, a.ApplyDenyFirst(ctx, s1, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyDenyFirst(ctx, s2, testSlot("u-2", "10.0.0.6")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s2, pol))

	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()

	// nft deletes rules only by handle and verdict maps cannot jump to
	// chains, so Remove rebuilds the whole table: header + remaining subjects
	// (subject 2 keeps its full policy, subject 1 is gone).
	require.NoError(t, a.Remove(ctx, s1))
	script := runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
	require.Contains(t, script, "8.8.8.8")
	assert.NotContains(t, script, "subj_s_u_1", "removed subject must not reappear in the rebuild")
	assert.NotContains(t, script, "10.0.0.5", "removed subject's dispatch must not reappear")

	// last subject removed: swap in the empty master drop chain (fail closed)
	require.NoError(t, a.Remove(ctx, s2))
	script = runner.last()
	require.Contains(t, script, "add chain inet opensandbox-fast-sandbox dispatch { type filter hook forward priority 0; policy accept; }")
	assert.NotContains(t, script, "subj_s_u_2", "no subjects may remain after removing the last one")

	// last subject removed: whole table deleted
	require.NoError(t, a.Remove(ctx, s2))
	script = runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
}

func TestRemoveKeepsRemainingSubjectsLeases(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	now := time.Unix(1_700_000_000, 0)
	a.now = func() time.Time { return now }
	ctx := context.Background()
	removed := subject.FromSandboxUID("u-1")
	kept := subject.FromSandboxUID("u-2")
	require.NoError(t, a.ApplyDenyFirst(ctx, removed, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyDenyFirst(ctx, kept, testSlot("u-2", "10.0.0.6")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"api.example.com"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, kept, pol))
	require.NoError(t, a.AddResolvedIPs(ctx, kept, "api.example.com", []nftables.ResolvedIP{
		{Addr: netip.MustParseAddr("192.0.2.1"), TTL: 0},                   // 60s lease
		{Addr: netip.MustParseAddr("2001:db8::1"), TTL: 300 * time.Second}, // 360s lease
		{Addr: netip.MustParseAddr("192.0.2.9"), TTL: 0},                   // expires before the rebuild
	}))
	a.states[kept].dyn[netip.MustParseAddr("192.0.2.9")] = now.Add(-time.Second)

	now = now.Add(20*time.Second + 500*time.Millisecond)
	require.NoError(t, a.Remove(ctx, removed))
	script := runner.last()
	require.Contains(t, script, fmt.Sprintf("add element inet %s %s { 192.0.2.1 timeout 40s }", TableName, dynSetName(kept, "v4")))
	require.Contains(t, script, fmt.Sprintf("add element inet %s %s { 2001:db8::1 timeout 340s }", TableName, dynSetName(kept, "v6")))
	assert.NotContains(t, script, "192.0.2.9", "an expired lease must not be re-added")
}

// TestRemoveFailureStaysRetryable: a failed nft transaction must not forget
// the subject from the in-memory map — otherwise the retry short-circuits to
// success and the stale same-IP dispatch rule stays first-match in the kernel
// ahead of any successor (takeover/REMOVE_BINDING retry convergence).
func TestRemoveFailureStaysRetryable(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	s1 := subject.FromSandboxUID("u-1")
	s2 := subject.FromSandboxUID("u-2")
	require.NoError(t, a.ApplyDenyFirst(ctx, s1, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyDenyFirst(ctx, s2, testSlot("u-2", "10.0.0.6")))

	runner.mu.Lock()
	runner.fail = func(string) error { return errors.New("nft busy") }
	runner.mu.Unlock()
	require.Error(t, a.Remove(ctx, s1))
	// the failed attempt must not have mutated the in-memory state
	a.mu.Lock()
	_, stillInstalled := a.subjects[s1]
	a.mu.Unlock()
	require.True(t, stillInstalled, "a failed removal must keep the subject retryable")

	// the retry re-emits a real rebuild (header + remaining subject) instead
	// of short-circuiting
	runner.mu.Lock()
	runner.fail = nil
	runner.mu.Unlock()
	before := runner.count()
	require.NoError(t, a.Remove(ctx, s1))
	assert.Greater(t, runner.count(), before, "the retry must re-run the nft transaction")
	script := runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
	require.Contains(t, script, "subj_s_u_2")
	assert.NotContains(t, script, "subj_s_u_1")

	// and the subject is gone for good: a further Remove is a genuine no-op
	before = runner.count()
	require.NoError(t, a.Remove(ctx, s1))
	assert.Equal(t, before, runner.count())
}

// TestApplyAlwaysRulesReloadRebuildsTable: one transaction swaps the port
// floor and re-emits every subject (merged policies, deny-first preserved,
// DNS leases dropped); the applier adopts the reloaded state only after
// the transaction commits.
func TestApplyAlwaysRulesReloadRebuildsTable(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	denyFirst := subject.FromSandboxUID("u-1")
	active := subject.FromSandboxUID("u-2")
	require.NoError(t, a.ApplyDenyFirst(ctx, denyFirst, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyDenyFirst(ctx, active, testSlot("u-2", "10.0.0.6")))
	oldPol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"},{"action":"allow","target":"example.com"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, active, oldPol))
	require.NoError(t, a.AddResolvedIPs(ctx, active, "example.com", []nftables.ResolvedIP{{Addr: netip.MustParseAddr("192.0.2.1"), TTL: 0}}))

	newDeny, err := policy.ParseValidatedEgressRule("deny", "203.0.113.0/24")
	require.NoError(t, err)
	newPol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"example.com"}]}`)
	require.NoError(t, err)
	merged := policy.MergeAlwaysOverlay(newPol, []policy.EgressRule{newDeny}, nil)
	floor := []policy.PortRange{{Lo: 1, Hi: 79}, {Lo: 81, Hi: 65535}}

	require.NoError(t, a.ApplyAlwaysRulesReload(ctx, floor, map[subject.Subject]*policy.NetworkPolicy{active: merged}))
	script := runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox", "the reload rebuilds the whole table")
	require.Contains(t, script, "tcp dport { 1-79, 81-65535 } drop", "the port floor is swapped into the master chains")
	require.Contains(t, script, "203.0.113.0/24", "the new always-deny CIDR reaches the subject's deny set")
	assert.NotContains(t, script, "8.8.8.8", "the replaced merged policy must not survive")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 drop", "deny-first subject keeps its bare drop")
	assert.NotContains(t, script, "192.0.2.1", "DNS-learned leases must be dropped with the table (sidecar parity: a tightened overlay must not keep revoked domains authorized)")

	// the applier adopted the reloaded policy: a later Remove rebuild (which
	// re-emits subjects from in-memory state) carries it too
	a.mu.Lock()
	adopted := a.subjects[active].pol
	a.mu.Unlock()
	require.Same(t, merged, adopted)
	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()
	require.NoError(t, a.Remove(ctx, denyFirst))
	require.Contains(t, runner.last(), "203.0.113.0/24", "rebuilds reuse the reloaded policy")
}

// TestApplyAlwaysRulesReloadFailureStaysRetryable: a failed reload leaves
// the in-memory policies and floor untouched, so the retry re-runs the
// full rebuild.
func TestApplyAlwaysRulesReloadFailureStaysRetryable(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	s := subject.FromSandboxUID("u-1")
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	oldPol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, oldPol))
	originalFloor := []policy.PortRange{{Lo: 1, Hi: 79}}
	a.mu.Lock()
	a.opts.PortFloorDenyRanges = originalFloor
	a.mu.Unlock()

	newPol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"9.9.9.9"}]}`)
	require.NoError(t, err)
	newFloor := []policy.PortRange{{Lo: 81, Hi: 65535}}
	runner.mu.Lock()
	runner.fail = func(string) error { return errors.New("nft busy") }
	runner.mu.Unlock()
	require.Error(t, a.ApplyAlwaysRulesReload(ctx, newFloor, map[subject.Subject]*policy.NetworkPolicy{s: newPol}))
	a.mu.Lock()
	keptPol := a.subjects[s].pol
	keptFloor := a.opts.PortFloorDenyRanges
	a.mu.Unlock()
	require.Same(t, oldPol, keptPol, "a failed reload must keep the installed policy")
	require.Equal(t, originalFloor, keptFloor, "a failed reload must keep the installed floor")

	// the retry re-runs the rebuild and adopts both
	runner.mu.Lock()
	runner.fail = nil
	runner.mu.Unlock()
	require.NoError(t, a.ApplyAlwaysRulesReload(ctx, newFloor, map[subject.Subject]*policy.NetworkPolicy{s: newPol}))
	script := runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
	require.Contains(t, script, "tcp dport { 81-65535 } drop")
	require.Contains(t, script, "9.9.9.9")
	a.mu.Lock()
	require.Same(t, newPol, a.subjects[s].pol)
	require.Equal(t, newFloor, a.opts.PortFloorDenyRanges)
	a.mu.Unlock()
}

// TestApplyAlwaysRulesReloadNeverUpgradesDenyFirst: a deny-first transition
// that raced the reload's snapshot (inst.pol == nil in the applier) must
// never be resurrected by the rebuild even when the caller's map still
// carries a policy for the subject — the kernel stays deny-first.
func TestApplyAlwaysRulesReloadNeverUpgradesDenyFirst(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	reverted := subject.FromSandboxUID("u-1")
	require.NoError(t, a.ApplyDenyFirst(ctx, reverted, testSlot("u-1", "10.0.0.5")))
	stillActive := subject.FromSandboxUID("u-2")
	require.NoError(t, a.ApplyDenyFirst(ctx, stillActive, testSlot("u-2", "10.0.0.6")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, stillActive, pol))
	// the race: u-1 reverts to deny-first (ApplyDenyFirst) AFTER the caller
	// snapshotted its (allow) policy into the reload map
	require.NoError(t, a.ApplyDenyFirst(ctx, reverted, testSlot("u-1", "10.0.0.5")))
	staleAllow, err := policy.ParsePolicy(`{"defaultAction":"allow"}`)
	require.NoError(t, err)

	floor := []policy.PortRange{{Lo: 1, Hi: 79}}
	require.NoError(t, a.ApplyAlwaysRulesReload(ctx, floor, map[subject.Subject]*policy.NetworkPolicy{
		reverted:    staleAllow,
		stillActive: pol,
	}))
	script := runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 drop",
		"the reverted subject must re-emit deny-first despite the stale map entry")
	assert.NotContains(t, script, "tcp dport { 1-65535 } drop", "no default-allow mark rules for the reverted subject")
	a.mu.Lock()
	require.Nil(t, a.subjects[reverted].pol, "the applier must not adopt a policy for a deny-first subject")
	require.Same(t, pol, a.subjects[stillActive].pol)
	a.mu.Unlock()
}

func TestDenyFirstResetsOnReRegistration(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()

	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"},{"action":"allow","target":"example.com"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	require.NoError(t, a.AddResolvedIPs(ctx, s, "example.com", []nftables.ResolvedIP{{Addr: netip.MustParseAddr("1.1.1.1"), TTL: time.Minute}}))

	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()

	// rebind: controller re-observes the same subject -> force reset
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	script := runner.last()
	require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox subj_s_u_1")
	require.Contains(t, script, "flush set inet opensandbox-fast-sandbox subj_s_u_1_dyn_v4", "DNS leases must be wiped on rebind")
	require.Contains(t, script, `add rule inet opensandbox-fast-sandbox dispatch ip saddr 10.0.0.5 jump subj_s_u_1`, "dispatch re-added")
	assert.NotContains(t, script, "8.8.8.8", "old policy must not survive a rebind")
	assert.NotContains(t, script, "1.1.1.1", "old DNS lease must not survive a rebind")
	assert.NotContains(t, script, "delete table inet opensandbox-fast-sandbox", "reset must not touch other subjects")

	// the applier's in-memory state is deny-first again: removal deletes the
	// last subject, so the whole table goes
	require.NoError(t, a.Remove(ctx, s))
	script = runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
}

func TestApplyResetKeepsEmptyMasterDropChain(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	s := subject.FromSandboxUID("u-1")
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyReset(ctx))

	// Reset swaps in an EMPTY master drop chain — the fail-closed guarantee
	// must not have a window where the drop hook is gone.
	script := runner.last()
	require.Contains(t, script, "delete table inet opensandbox-fast-sandbox")
	require.Contains(t, script, "add chain inet opensandbox-fast-sandbox dispatch { type filter hook forward priority 0; policy accept; }")
	assert.NotContains(t, script, "subj_s_u_1", "reset must not carry subjects")
	assert.NotContains(t, script, "10.0.0.5", "reset must not carry dispatch rules")

	// after reset the table already exists: re-registration adds only the
	// subject fragment (no delete-table header, no dispatch chain rebuild)
	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	assert.NotContains(t, runner.last(), "delete table", "table must not be recreated after reset")
	assert.NotContains(t, runner.last(), "add chain inet opensandbox-fast-sandbox dispatch", "dispatch chain already exists after reset")
	require.Contains(t, runner.last(), "add chain inet opensandbox-fast-sandbox subj_s_u_1")
}

func TestApplyDenyFirstReRegistersWithNewAttachment(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	ctx := context.Background()
	s := subject.FromSandboxUID("u-1")
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()

	// rebind with a moved veth/IP: deny-first re-registration resets the
	// subject (flush + new dispatch rule) WITHOUT recreating the table
	att2 := testSlot("u-1", "10.0.0.9")
	att2.HostVeth = "veth-new"
	require.NoError(t, a.ApplyDenyFirst(ctx, s, att2))
	script := runner.last()
	require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox subj_s_u_1")
	require.Contains(t, script, `add rule inet opensandbox-fast-sandbox dispatch ip saddr 10.0.0.9 jump subj_s_u_1`)
	assert.NotContains(t, script, "delete table", "rebind must not recreate the table")

	// unknown subject rejected on deny-first? No: deny-first installs; only
	// policy applies require a prior install.
	require.ErrorIs(t, a.ApplyPolicy(ctx, subject.FromSandboxUID("ghost"), nil), ErrUnknownSubject)
}

func TestSanitize(t *testing.T) {
	assert.Equal(t, "subj_s_abc_def", subjectChain(subject.Subject("s-abc:def")))
	assert.Equal(t, "subj_s_u_1", subjectChain(subject.FromSandboxUID("u-1")))
	assert.Equal(t, "mark_s_u_1", markChainName(subject.FromSandboxUID("u-1")))
}

// TestMarkBasedAllowShapes: the forward path never accepts explicitly — the
// per-subject prerouting mark chain marks allow/dyn members (default-deny) or
// everything (default-allow), and the master chain drops unmarked traffic.
func TestMarkBasedAllowShapes(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()

	// default-deny policy: allow/dyn marks, deny drops only in the forward
	// chain (no accept verdicts)
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	script := runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox mark_s_u_1 ip daddr @subj_s_u_1_allow_v4 meta mark set 0x2")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox mark_s_u_1 ip daddr @subj_s_u_1_dyn_v4 meta mark set 0x2")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 ip daddr @subj_s_u_1_deny_v4 drop")
	assert.NotContains(t, script, "subj_s_u_1 ip daddr @subj_s_u_1_allow_v4 accept", "forward path must not accept explicitly")
	assert.NotContains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 accept")
	assert.NotContains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 drop")

	// default-allow policy: unconditional mark; deny sets still drop
	pol2, err := policy.ParsePolicy(`{"defaultAction":"allow","egress":[{"action":"deny","target":"9.9.9.9"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol2))
	script = runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox mark_s_u_1 meta mark set 0x2")
	assert.NotContains(t, script, "ip daddr @subj_s_u_1_allow_v4 meta mark", "default-allow must not need set-based marks")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 ip daddr @subj_s_u_1_deny_v4 drop")

	// deny-first reset: mark chain flushed, no mark rules, drop-only forward
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	script = runner.last()
	require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox mark_s_u_1")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 drop")
	assert.NotContains(t, script, "meta mark set", "deny-first must not mark anything")
}

func TestWriteDispatchRuleV6(t *testing.T) {
	var b strings.Builder
	writeDispatchRule(&b, subject.FromSandboxUID("u-1"), testSlot("u-1", "fd00::5"), 0)
	require.Contains(t, b.String(), `add rule inet opensandbox-fast-sandbox dispatch ip6 saddr fd00::5 jump subj_s_u_1`)
	require.Contains(t, b.String(), `add rule inet opensandbox-fast-sandbox marking ip6 saddr fd00::5 jump mark_s_u_1`)
}

// TestIifnameBindingInDispatchRule: the host-veth binding lives in the
// dispatch rule (defense in depth against UDP spoofing) and survives policy
// swaps (the swap never touches the master chain).
func TestIifnameBindingInDispatchRule(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()

	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.Contains(t, runner.last(), `add rule inet opensandbox-fast-sandbox dispatch ip saddr 10.0.0.5 jump subj_s_u_1`)

	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	require.NotContains(t, runner.last(), "add rule inet opensandbox-fast-sandbox dispatch", "swap must not duplicate the dispatch rule")

	// rebind re-adds the dispatch rule for the (possibly changed) slot
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.Contains(t, runner.last(), `add rule inet opensandbox-fast-sandbox dispatch ip saddr 10.0.0.5 jump subj_s_u_1`)
}

// TestApplyDenyFirstMissingTableFallback: the first install on a fresh table
// fails on `delete table` (table already gone via ApplyReset); the applier
// must retry without the delete line instead of failing forever.
func TestApplyDenyFirstMissingTableFallback(t *testing.T) {
	var attempts atomic.Int32
	runner := &fakeRunner{fail: func(script string) error {
		if strings.Contains(script, "delete table inet opensandbox-fast-sandbox") && attempts.Add(1) == 1 {
			return nftMissingObjectError("delete table inet opensandbox-fast-sandbox")
		}
		return nil
	}}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()

	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.Equal(t, int32(1), attempts.Load(), "one failed attempt with delete-table line, then fallback")
	assert.NotContains(t, runner.last(), "delete table", "fallback script must not contain the delete-table line")
	require.Contains(t, runner.last(), "add table inet opensandbox-fast-sandbox")
}

// TestOverlappingIntervalsNormalized: an always-deny host inside a policy
// deny CIDR must not reach nft as "conflicting intervals specified"; the
// strict subnet is dropped before writing.
func TestOverlappingIntervalsNormalized(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	// deny.always 10.99.0.9 + policy deny 10.99.0.0/24 overlap
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"deny","target":"10.99.0.0/24"},{"action":"deny","target":"10.99.0.9"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))

	script := runner.last()
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox subj_s_u_1_deny_v4 { 10.99.0.0/24 }")
	assert.NotContains(t, script, "10.99.0.9", "strict subnet inside a CIDR must be normalized away")
}

func TestDoHBlockRulesWithBlocklist(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{
		BlockDoH443:    true,
		DoHBlocklistV4: []string{"10.99.0.9", "10.99.0.0/24"},
		DoHBlocklistV6: []string{"2001:db8::/32"},
	})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	// global interval sets + per-family drop rules in the master chain
	require.Contains(t, script, "add set inet opensandbox-fast-sandbox doh_block_v4 { type ipv4_addr; flags interval; }")
	require.Contains(t, script, "add set inet opensandbox-fast-sandbox doh_block_v6 { type ipv6_addr; flags interval; }")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch ip daddr @doh_block_v4 tcp dport 443 drop")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch ip6 daddr @doh_block_v6 tcp dport 443 drop")
	// overlapping 10.99.0.9 inside 10.99.0.0/24 is normalized away
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox doh_block_v4 { 10.99.0.0/24 }")
	assert.NotContains(t, script, "10.99.0.9", "strict subnet inside a doh blocklist CIDR must be normalized away")
	// blocklist mode is NOT strict: no bare 443 drop
	assert.NotContains(t, script, "add rule inet opensandbox-fast-sandbox dispatch tcp dport 443 drop")
}

func TestDoHStrictModeDropsAll443(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{BlockDoH443: true})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch tcp dport 443 drop")
	assert.NotContains(t, script, "doh_block", "strict mode has no blocklist sets")
}

func TestDoHDisabledByDefault(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	assert.NotContains(t, script, "doh_block", "DoH-443 must be off unless enabled")
	assert.NotContains(t, script, "dport 443", "DoH-443 must be off unless enabled")
}

// TestDoHRulesSurviveRebuild: the DoH rules are part of the table header, so
// every rebuild (last-subject removal, startup reset) must keep them.
func TestDoHRulesSurviveRebuild(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{BlockDoH443: true, DoHBlocklistV4: []string{"10.99.0.2"}})
	ctx := context.Background()
	s := subject.FromSandboxUID("u-1")
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.Remove(ctx, s))
	require.Contains(t, runner.last(), "add set inet opensandbox-fast-sandbox doh_block_v4", "empty-table swap must keep DoH rules")
	require.NoError(t, a.ApplyReset(ctx))
	require.Contains(t, runner.last(), "add rule inet opensandbox-fast-sandbox dispatch ip daddr @doh_block_v4 tcp dport 443 drop", "reset must keep DoH rules")
}

// TestInputChainInstalledWithMITM: the Pod-netns INPUT enforcement chain is
// the authoritative layer for intercepted (DNATed) traffic — the forward
// hook never sees it. Deny-first must install the chain, the per-subject
// dispatch (ct status dnat on the mitm port) and the ct-original verdicts.
func TestInputChainInstalledWithMITM(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	require.Contains(t, script, "add chain inet opensandbox-fast-sandbox input { type filter hook input priority 0; policy accept; }")
	require.Contains(t, script, "add chain inet opensandbox-fast-sandbox subj_s_u_1_in")
	require.Contains(t, script, `add rule inet opensandbox-fast-sandbox input ip saddr 10.0.0.5 tcp dport 18081 ct status dnat jump subj_s_u_1_in`)
	// a direct (non-DNATed) connection to the mitm port must be dropped —
	// default-allow sandboxes must not bypass the transparent interception
	require.Contains(t, script, `add rule inet opensandbox-fast-sandbox input ip saddr 10.0.0.5 ip daddr 10.0.0.1 tcp dport 18081 drop`)
	// verdicts match the conntrack ORIGINAL destination (the DNATed dst is
	// the local mitm port)
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1_in ct original ip daddr @subj_s_u_1_deny_v4 drop")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1_in ct original ip daddr @subj_s_u_1_allow_v4 accept")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1_in drop", "deny-first default in the input chain")
}

// TestInputChainAbsentWithoutMITM: no MITM, no input chain — the forward
// hook is the only enforcement layer and Pod traffic is untouched.
func TestInputChainAbsentWithoutMITM(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	assert.NotContains(t, runner.last(), "hook input", "no MITM: input chain must not be installed")
	assert.NotContains(t, runner.last(), "subj_s_u_1_in", "no MITM: per-subject input chain must not exist")
}

// TestInputChainDoHBlocklist: DoH-443 blocking on the input chain matches
// the ORIGINAL port/destination (the DNATed dst is the mitm port).
func TestInputChainDoHBlocklist(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{
		BlockDoH443:      true,
		DoHBlocklistV4:   []string{"10.99.0.2"},
		MitmRedirectPort: 18081,
	})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox input ct status dnat ct original ip daddr @doh_block_v4 ct original proto-dst 443 drop")
}

// TestInputChainPolicySwap: a policy swap rewrites the input-chain verdicts
// with the new sets (and keeps the dispatch rule untouched).
func TestInputChainPolicySwap(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"8.8.8.8"}]}`)
	require.NoError(t, err)
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	script := runner.last()
	require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox subj_s_u_1_in")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1_in ct original ip daddr @subj_s_u_1_allow_v4 accept")
	assert.NotContains(t, script, "add rule inet opensandbox-fast-sandbox input ip saddr", "swap must not duplicate the input dispatch rule")
}

// TestUpstreamProxyForwardDrops: the chained upstream proxy endpoint is
// infrastructure — a sandbox CONNECTing it directly would relay to
// otherwise-denied destinations, so the drop rules sit profile-wide in the
// master dispatch chain, BEFORE the established accept (stale flows from a
// pre-upstream egress generation must not survive a restart) and before any
// per-subject jump.
func TestUpstreamProxyForwardDrops(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{
		UpstreamProxy: &UpstreamProxyEndpoint{
			Port:       3128,
			LiteralIPs: []netip.Addr{netip.MustParseAddr("10.1.2.3"), netip.MustParseAddr("2001:db8::1")},
		},
	})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	require.Contains(t, script, "add set inet opensandbox-fast-sandbox upstream_proxy_v4 { type ipv4_addr; flags timeout; }")
	require.Contains(t, script, "add set inet opensandbox-fast-sandbox upstream_proxy_v6 { type ipv6_addr; flags timeout; }")
	// literal seeds are permanent: no element-level timeout
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.1.2.3 }\n")
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v6 { 2001:db8::1 }\n")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch ip daddr @upstream_proxy_v4 tcp dport 3128 drop")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch ip6 daddr @upstream_proxy_v6 tcp dport 3128 drop")
	// the drop must precede the established accept (cross-restart staleness)
	require.Less(t,
		strings.Index(script, "dispatch ip daddr @upstream_proxy_v4"),
		strings.Index(script, "dispatch ct state established,related accept"),
	)
	// no MITM: no input chain, so no input-path containment either
	assert.NotContains(t, script, "hook input")
	assert.NotContains(t, script, "input ct status dnat ct original ip daddr @upstream_proxy_v4")
}

// TestUpstreamProxyInputDropsWithMITM: intercepted CONNECTs whose ORIGINAL
// destination is the proxy endpoint die in the input chain, before its
// established accept — the forward drop never sees DNATed traffic.
func TestUpstreamProxyInputDropsWithMITM(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{
		MitmRedirectPort: 18081,
		UpstreamProxy:    &UpstreamProxyEndpoint{Port: 3128},
	})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox input ct status dnat ct original ip daddr @upstream_proxy_v4 ct original proto-dst 3128 drop")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox input ct status dnat ct original ip6 daddr @upstream_proxy_v6 ct original proto-dst 3128 drop")
	require.Less(t,
		strings.Index(script, "input ct status dnat ct original ip daddr @upstream_proxy_v4"),
		strings.Index(script, "input ct state established,related accept"),
		"input drop must precede the input established accept",
	)
}

func TestUpstreamProxyDisabledByDefault(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run)
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	assert.NotContains(t, runner.last(), "upstream_proxy", "no upstream proxy: no containment rules")

	// AddUpstreamProxyIPs without an endpoint is a no-op (no nft call, no error)
	require.NoError(t, a.AddUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("1.2.3.4"), TTL: time.Minute}}))
	require.Equal(t, 1, runner.count())
}

func TestAddUpstreamProxyIPs(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128}})
	ctx := context.Background()
	require.NoError(t, a.ApplyReset(ctx))
	runner.mu.Lock()
	runner.scripts = nil
	runner.mu.Unlock()

	// TTLs are deliberately ignored: elements are permanent so containment
	// survives egress downtime (expiry is owned by SyncUpstreamProxyIPs).
	require.NoError(t, a.AddUpstreamProxyIPs(ctx, []nftables.ResolvedIP{
		{Addr: netip.MustParseAddr("10.9.9.9"), TTL: 30 * time.Second},
		{Addr: netip.MustParseAddr("2001:db8::2"), TTL: 24 * time.Hour},
	}))
	script := runner.last()
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }\n")
	require.Contains(t, script, "delete element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }")
	assert.NotContains(t, script, "10.9.9.9 timeout", "DNS-learned elements must be permanent")
	assert.NotContains(t, script, "2001:db8::2 timeout", "DNS-learned elements must be permanent")

	// an empty slice is a no-op
	require.NoError(t, a.AddUpstreamProxyIPs(ctx, nil))
	require.Equal(t, 1, runner.count())
}

// TestUpstreamProxyLearnedIPsSurviveRebuild: table rebuilds (subject removal,
// startup reset) re-seed the DNS-learned drop elements from the in-memory
// mirror, so hostname containment never lapses between the rebuild and the
// next refresh tick.
func TestUpstreamProxyLearnedIPsSurviveRebuild(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{
		UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128, LiteralIPs: []netip.Addr{netip.MustParseAddr("10.1.2.3")}},
	})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.AddUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.9.9.9"), TTL: time.Minute}}))

	// subject removal rebuilds the whole table from in-memory state
	require.NoError(t, a.Remove(ctx, s))
	script := runner.last()
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.1.2.3 }\n", "literal seed must survive")
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }\n", "learned element must be re-seeded (permanent)")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox dispatch ip daddr @upstream_proxy_v4 tcp dport 3128 drop", "drop rule must survive")

	// startup reset likewise
	require.NoError(t, a.ApplyReset(ctx))
	require.Contains(t, runner.last(), "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }\n")
	require.Contains(t, runner.last(), "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.1.2.3 }\n")
}

// TestSyncUpstreamProxyIPs: the refresh loop's sync is the expiry mechanism
// for the containment — rotation removes stale addresses, and empty or
// unusable answers never prune the sets to nothing (fail-closed retention).
func TestSyncUpstreamProxyIPs(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128}})
	ctx := context.Background()
	require.NoError(t, a.ApplyReset(ctx))
	require.NoError(t, a.AddUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.9.9.9")}}))

	// One missing snapshot must retain the address, including across rebuilds.
	require.NoError(t, a.SyncUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.8.8.8")}}))
	require.NoError(t, a.ApplyReset(ctx))
	require.Contains(t, runner.last(), "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }")
	// A second successful full refresh confirms rotation.
	require.NoError(t, a.SyncUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.8.8.8")}}))
	script := runner.last()
	require.Contains(t, script, "delete element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }")
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.8.8.8 }")

	// the mirror follows the rotation: rebuilds drop the stale address
	require.NoError(t, a.ApplyReset(ctx))
	rebuilt := runner.last()
	require.Contains(t, rebuilt, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.8.8.8 }\n")
	assert.NotContains(t, rebuilt, "10.9.9.9")

	// empty or all-unusable answers are errors, never a prune-to-nothing
	require.Error(t, a.SyncUpstreamProxyIPs(ctx, nil))
	require.Error(t, a.SyncUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.Addr{}}}))
	require.NoError(t, a.ApplyReset(ctx))
	require.Contains(t, runner.last(), "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.8.8.8 }\n", "failed sync must keep the mirror")

	// a failed apply must not commit the rotation either
	failing := &fakeRunner{}
	b := NewApplier(failing.Run, Options{UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128}})
	require.NoError(t, b.ApplyReset(ctx))
	require.NoError(t, b.AddUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.9.9.9")}}))
	failing.fail = func(script string) error {
		if strings.Contains(script, "10.8.8.8") {
			return fmt.Errorf("nft apply failed")
		}
		return nil
	}
	require.Error(t, b.SyncUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.8.8.8")}}))
	require.NoError(t, b.ApplyReset(ctx))
	assert.NotContains(t, failing.last(), "10.8.8.8", "failed rotation must not leak into the rebuild")
	require.Contains(t, failing.last(), "10.9.9.9")

	// no endpoint configured: no-op
	c := NewApplier((&fakeRunner{}).Run)
	require.NoError(t, c.SyncUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.8.8.8")}}))
}

// TestSeedUpstreamProxyIPsFailClosed: the first seed retries with
// bounded backoff and returns an error when the hostname cannot be
// resolved — the caller fails startup instead of serving sandboxes with an
// empty drop set.
func TestSeedUpstreamProxyIPsFailClosed(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128}})
	a.upstreamSeedTimeout = 80 * time.Millisecond
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// persistent lookup failure: seed retries, then errors with the cause
	err := a.SeedUpstreamProxyIPs(ctx, "proxy.test", func(context.Context, string) ([]nftables.ResolvedIP, error) {
		return nil, fmt.Errorf("dns down")
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "dns down")

	// NXDOMAIN-everywhere is equally fatal for the first seed
	err = a.SeedUpstreamProxyIPs(ctx, "proxy.test", func(context.Context, string) ([]nftables.ResolvedIP, error) {
		return nil, nil
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "no addresses")

	// nothing was seeded: no nft call ever succeeded
	require.Equal(t, 0, runner.count())
}

// The seed does not modify the kernel; the first reset includes containment.
func TestSeedUpstreamProxyIPsBeforeReset(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128}})
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	require.NoError(t, a.SeedUpstreamProxyIPs(ctx, "proxy.test", func(context.Context, string) ([]nftables.ResolvedIP, error) {
		return []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.9.9.9"), TTL: time.Minute}}, nil
	}))
	require.Zero(t, runner.count(), "resolution must leave the previous kernel table untouched")
	require.NoError(t, a.ApplyReset(ctx))
	require.Equal(t, 1, runner.count(), "the first transaction must already contain the seed")
	script := runner.last()
	require.Contains(t, script, "add element inet opensandbox-fast-sandbox upstream_proxy_v4 { 10.9.9.9 }")
	assert.NotContains(t, script, "10.9.9.9 timeout", "seeded elements must be permanent")
}

// TestAddUpstreamProxyIPsFailureKeepsMirror: a failed apply must not commit
// the mirror (rebuilds stay deterministic against the kernel state).
func TestAddUpstreamProxyIPsFailureKeepsMirror(t *testing.T) {
	runner := &fakeRunner{fail: func(script string) error {
		// fail only the dynamic element update, never the table header
		if strings.Contains(script, "delete element") && strings.Contains(script, "upstream_proxy") {
			return fmt.Errorf("nft apply failed")
		}
		return nil
	}}
	a := NewApplier(runner.Run, Options{UpstreamProxy: &UpstreamProxyEndpoint{Port: 3128}})
	ctx := context.Background()
	require.NoError(t, a.ApplyReset(ctx))
	require.Error(t, a.AddUpstreamProxyIPs(ctx, []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.9.9.9"), TTL: time.Minute}}))

	require.NoError(t, a.ApplyReset(ctx))
	assert.NotContains(t, runner.last(), "10.9.9.9", "failed update must not leak into the rebuild")
}

func TestPortFloorDropsInDispatchAndInputChains(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{
		MitmRedirectPort:    18081,
		PortFloorDenyRanges: []policy.PortRange{{Lo: 1, Hi: 79}, {Lo: 81, Hi: 442}, {Lo: 444, Hi: 65535}},
	})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))

	script := runner.last()
	floorDispatch := "add rule inet opensandbox-fast-sandbox dispatch tcp dport { 1-79, 81-442, 444-65535 } drop"
	floorInput := "add rule inet opensandbox-fast-sandbox input ct status dnat tcp dport 18081 ct original proto-dst { 1-79, 81-442, 444-65535 } drop"
	require.Contains(t, script, floorDispatch, "the floor must gate the forward path profile-wide")
	require.Contains(t, script, floorInput, "the floor must gate MITM-redirected traffic by its ORIGINAL port only, leaving fsb DNS (REDIRECT to :15353) and pod-inbound flows alone")
	// Both drops precede the fail-closed tail.
	require.Less(t, strings.Index(script, floorDispatch), strings.Index(script, "meta mark &"))

	// No floor configured: no floor rules at all.
	plain := &fakeRunner{}
	noFloor := NewApplier(plain.Run, Options{})
	require.NoError(t, noFloor.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	assert.NotContains(t, plain.last(), "tcp dport { 1-79")
}

func TestPortScopedPolicyRules(t *testing.T) {
	targets := []struct {
		name   string
		target string
		daddr  string
	}{
		{name: "port_only"},
		{name: "ipv4", target: "10.0.0.9", daddr: "ip daddr 10.0.0.9 "},
		{name: "cidr4", target: "10.0.0.0/24", daddr: "ip daddr 10.0.0.0/24 "},
		{name: "ipv6", target: "2001:db8::9", daddr: "ip6 daddr 2001:db8::9 "},
		{name: "cidr6", target: "2001:db8::/64", daddr: "ip6 daddr 2001:db8::/64 "},
	}
	for _, target := range targets {
		for _, action := range []string{policy.ActionAllow, policy.ActionDeny} {
			for _, defaultAction := range []string{policy.ActionAllow, policy.ActionDeny} {
				for _, mitmPort := range []int{0, 18081} {
					t.Run(fmt.Sprintf("%s/%s/default_%s/mitm_%d", target.name, action, defaultAction, mitmPort), func(t *testing.T) {
						runner := &fakeRunner{}
						a := NewApplier(runner.Run, Options{MitmRedirectPort: mitmPort})
						s := subject.FromSandboxUID("u-1")
						ctx := context.Background()
						require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
						pol, err := policy.ParsePolicy(fmt.Sprintf(`{"defaultAction":%q,"egress":[{"action":%q,"target":%q,"ports":[1,443,65535]}]}`, defaultAction, action, target.target))
						require.NoError(t, err)
						require.NoError(t, a.ApplyPolicy(ctx, s, pol))
						script := runner.last()
						predicate := target.daddr + "tcp dport { 1, 443, 65535 }"
						forwardRule := "add rule inet opensandbox-fast-sandbox subj_s_u_1 " + predicate + " drop"
						markRule := "add rule inet opensandbox-fast-sandbox mark_s_u_1 " + predicate + " meta mark set 0x2"
						if action == policy.ActionDeny {
							require.Contains(t, script, forwardRule)
							assert.NotContains(t, script, markRule)
						} else {
							assert.NotContains(t, script, forwardRule)
							if defaultAction == policy.ActionDeny {
								require.Contains(t, script, markRule)
							} else {
								require.Contains(t, script, "add rule inet opensandbox-fast-sandbox mark_s_u_1 meta mark set 0x2")
								assert.NotContains(t, script, markRule)
							}
						}
						assert.NotContains(t, script, "add element", "port-scoped targets must not enter portless sets")
						assert.NotContains(t, script, "udp dport")
						if mitmPort == 0 {
							assert.NotContains(t, script, "ct original")
							assert.NotContains(t, script, "subj_s_u_1_in")
							return
						}
						originalTarget := ""
						if target.daddr != "" {
							originalTarget = "ct original " + target.daddr
						}
						verdict := "accept"
						if action == policy.ActionDeny {
							verdict = "drop"
						}
						inputRule := "add rule inet opensandbox-fast-sandbox subj_s_u_1_in " + originalTarget + "meta l4proto tcp ct original proto-dst { 1, 443, 65535 } " + verdict
						require.Contains(t, script, inputRule)
						defaultVerdict := "accept"
						if defaultAction == policy.ActionDeny {
							defaultVerdict = "drop"
						}
						defaultRule := "add rule inet opensandbox-fast-sandbox subj_s_u_1_in " + defaultVerdict + "\n"
						require.Less(t, strings.Index(script, inputRule), strings.Index(script, defaultRule))
						assert.NotContains(t, script, "ct original proto-dst { 18081 }")
					})
				}
			}
		}
	}
}

func TestPortScopedPolicyMaxPorts(t *testing.T) {
	members := make([]string, 256)
	for i := range members {
		members[i] = fmt.Sprintf("%d", i+1)
	}
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","ports":[` + strings.Join(members, ",") + `]}]}`)
	require.NoError(t, err)
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081})
	s := subject.FromSandboxUID("u-1")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	ports := "{ " + strings.Join(members, ", ") + " }"
	require.Contains(t, runner.last(), "mark_s_u_1 tcp dport "+ports+" meta mark set 0x2")
	require.Contains(t, runner.last(), "subj_s_u_1_in meta l4proto tcp ct original proto-dst "+ports+" accept")
}

func TestPortScopedApplyFailureKeepsDenyFirst(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081})
	s := subject.FromSandboxUID("u-1")
	other := subject.FromSandboxUID("u-2")
	ctx := context.Background()
	require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
	require.NoError(t, a.ApplyDenyFirst(ctx, other, testSlot("u-2", "10.0.0.6")))
	pol, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","ports":[443]}]}`)
	require.NoError(t, err)
	runner.fail = func(string) error { return errors.New("nft rejected transaction") }
	require.Error(t, a.ApplyPolicy(ctx, s, pol))
	assert.Nil(t, a.subjects[s].pol)
	runner.fail = nil
	require.NoError(t, a.Remove(ctx, other))
	script := runner.last()
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1 drop")
	require.Contains(t, script, "add rule inet opensandbox-fast-sandbox subj_s_u_1_in drop")
	assert.NotContains(t, script, "meta mark set")
	assert.NotContains(t, script, "{ 443 }")
	require.NoError(t, a.ApplyPolicy(ctx, s, pol))
	require.Contains(t, runner.last(), "mark_s_u_1 tcp dport { 443 } meta mark set 0x2")
}

func TestPortScopedDenyPrecedesEveryAllow(t *testing.T) {
	for _, defaultAction := range []string{policy.ActionAllow, policy.ActionDeny} {
		t.Run(defaultAction, func(t *testing.T) {
			runner := &fakeRunner{}
			a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081})
			s := subject.FromSandboxUID("u-1")
			ctx := context.Background()
			require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
			pol, err := policy.ParsePolicy(fmt.Sprintf(`{"defaultAction":%q,"egress":[
				{"action":"allow","ports":[443]},
				{"action":"allow","target":"10.0.0.0/24"},
				{"action":"allow","target":"2001:db8::/64"},
				{"action":"allow","target":"example.com"},
				{"action":"deny","target":"10.0.0.9","ports":[443]},
				{"action":"deny","target":"2001:db8::9","ports":[443]},
				{"action":"deny","ports":[25]},
				{"action":"deny","target":"10.0.0.10"},
				{"action":"deny","target":"2001:db8::10"}
			]}`, defaultAction))
			require.NoError(t, err)
			require.NoError(t, a.ApplyPolicy(ctx, s, pol))
			script := runner.last()
			inputPrefix := "add rule inet opensandbox-fast-sandbox subj_s_u_1_in "
			firstAllow := strings.Index(script, inputPrefix+"meta l4proto tcp ct original proto-dst { 443 } accept")
			require.NotEqual(t, -1, firstAllow)
			for _, predicate := range []string{
				"ct original ip daddr 10.0.0.9 meta l4proto tcp ct original proto-dst { 443 }",
				"ct original ip6 daddr 2001:db8::9 meta l4proto tcp ct original proto-dst { 443 }",
				"meta l4proto tcp ct original proto-dst { 25 }",
				"ct original ip daddr @subj_s_u_1_deny_v4",
				"ct original ip6 daddr @subj_s_u_1_deny_v6",
			} {
				drop := inputPrefix + predicate + " drop"
				require.Contains(t, script, drop)
				require.Less(t, strings.Index(script, drop), firstAllow)
			}
			for _, set := range []string{"dyn_v4", "dyn_v6", "allow_v4", "allow_v6"} {
				family := "ip"
				if strings.HasSuffix(set, "v6") {
					family = "ip6"
				}
				allow := inputPrefix + "ct original " + family + " daddr @subj_s_u_1_" + set + " accept"
				require.Contains(t, script, allow)
				require.Less(t, firstAllow, strings.Index(script, allow))
			}
			for _, line := range strings.Split(script, "\n") {
				if strings.HasPrefix(line, "add rule inet opensandbox-fast-sandbox subj_s_u_1 ") || strings.HasPrefix(line, "add rule inet opensandbox-fast-sandbox mark_s_u_1 ") {
					assert.NotContains(t, line, " accept")
				}
			}
		})
	}
}

func TestPortScopedPolicyLifecycle(t *testing.T) {
	for _, mitmPort := range []int{0, 18081} {
		t.Run(fmt.Sprintf("mitm_%d", mitmPort), func(t *testing.T) {
			runner := &fakeRunner{}
			a := NewApplier(runner.Run, Options{MitmRedirectPort: mitmPort})
			s := subject.FromSandboxUID("u-1")
			other := subject.FromSandboxUID("u-2")
			ctx := context.Background()
			require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
			require.NoError(t, a.ApplyDenyFirst(ctx, other, testSlot("u-2", "10.0.0.6")))
			old, err := policy.ParsePolicy(`{"defaultAction":"deny","egress":[{"action":"allow","target":"10.0.0.9","ports":[8443]},{"action":"deny","ports":[25]},{"action":"allow","target":"example.com"}]}`)
			require.NoError(t, err)
			require.NoError(t, a.ApplyPolicy(ctx, s, old))
			require.NoError(t, a.AddResolvedIPs(ctx, s, "example.com", []nftables.ResolvedIP{{Addr: netip.MustParseAddr("10.0.0.20"), TTL: time.Minute}}))

			next, err := policy.ParsePolicy(`{"defaultAction":"allow","egress":[{"action":"deny","target":"10.0.0.9","ports":[443]}]}`)
			require.NoError(t, err)
			before := runner.count()
			runner.fail = func(string) error { return errors.New("nft rejected transaction") }
			require.Error(t, a.ApplyPolicy(ctx, s, next))
			require.Equal(t, before+1, runner.count())
			assert.Same(t, old, a.subjects[s].pol)
			runner.fail = nil

			require.NoError(t, a.Remove(ctx, other))
			script := runner.last()
			require.Contains(t, script, "ip daddr 10.0.0.9 tcp dport { 8443 } meta mark set 0x2")
			require.Contains(t, script, "tcp dport { 25 } drop")
			assert.NotContains(t, script, "tcp dport { 443 }")
			assert.NotContains(t, script, "subj_s_u_2")
			if mitmPort > 0 {
				require.Contains(t, script, "ct original ip daddr 10.0.0.9 meta l4proto tcp ct original proto-dst { 8443 } accept")
				require.Contains(t, script, "meta l4proto tcp ct original proto-dst { 25 } drop")
			}

			before = runner.count()
			require.NoError(t, a.ApplyPolicy(ctx, s, next))
			require.Equal(t, before+1, runner.count(), "the policy update must be one transaction")
			script = runner.last()
			require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox mark_s_u_1")
			require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox subj_s_u_1")
			require.Contains(t, script, "ip daddr 10.0.0.9 tcp dport { 443 } drop")
			require.Contains(t, script, "mark_s_u_1 meta mark set 0x2")
			assert.NotContains(t, script, "8443")
			assert.NotContains(t, script, "{ 25 }")
			assert.NotContains(t, script, "flush set inet opensandbox-fast-sandbox subj_s_u_1_dyn")
			assert.Contains(t, a.states[s].dyn, netip.MustParseAddr("10.0.0.20"))
			if mitmPort > 0 {
				require.Contains(t, script, "flush chain inet opensandbox-fast-sandbox subj_s_u_1_in")
				require.Contains(t, script, "ct original ip daddr 10.0.0.9 meta l4proto tcp ct original proto-dst { 443 } drop")
			}

			require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.7")))
			script = runner.last()
			assert.NotContains(t, script, "meta mark set")
			assert.NotContains(t, script, "tcp dport { 443 }")
			require.Contains(t, script, "flush set inet opensandbox-fast-sandbox subj_s_u_1_dyn_v4")
			assert.Nil(t, a.subjects[s].pol)
			assert.NotContains(t, a.states, s)
			require.NoError(t, a.ApplyPolicy(ctx, s, nil))
			assert.NotContains(t, runner.last(), "mark_s_u_1 meta mark set")
			assert.NotContains(t, runner.last(), "tcp dport {")
			assert.Equal(t, policy.ActionDeny, a.subjects[s].pol.DefaultAction)
			assert.Empty(t, a.subjects[s].pol.Egress)
			require.NoError(t, a.Remove(ctx, s))
			assert.NotContains(t, runner.last(), "subj_s_u_1")
			require.Contains(t, runner.last(), "dispatch meta mark & 0x2 != 0x2 drop")
		})
	}
}

func TestPortScopedSubjectIsolation(t *testing.T) {
	runner := &fakeRunner{}
	a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081})
	ctx := context.Background()
	for i, port := range []int{443, 8443} {
		uid := fmt.Sprintf("u-%d", i+1)
		s := subject.FromSandboxUID(uid)
		require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot(uid, fmt.Sprintf("10.0.0.%d", i+5))))
		pol, err := policy.ParsePolicy(fmt.Sprintf(`{"defaultAction":"deny","egress":[{"action":"allow","ports":[%d]}]}`, port))
		require.NoError(t, err)
		require.NoError(t, a.ApplyPolicy(ctx, s, pol))
		assert.NotContains(t, runner.last(), fmt.Sprintf("subj_s_u_%d", 2-i))
	}
	require.NoError(t, a.Remove(ctx, subject.FromSandboxUID("u-1")))
	script := runner.last()
	require.Contains(t, script, "ip saddr 10.0.0.6 jump mark_s_u_2")
	require.Contains(t, script, "mark_s_u_2 tcp dport { 8443 } meta mark set 0x2")
	require.Contains(t, script, "subj_s_u_2_in meta l4proto tcp ct original proto-dst { 8443 } accept")
	assert.NotContains(t, script, "{ 443 }")
	assert.NotContains(t, script, "subj_s_u_1")
}

func TestPortScopedPolicyComposesWithPlatformFloor(t *testing.T) {
	for _, defaultAction := range []string{policy.ActionAllow, policy.ActionDeny} {
		t.Run(defaultAction, func(t *testing.T) {
			ranges := []policy.PortRange{{Lo: 1, Hi: 79}, {Lo: 81, Hi: 442}, {Lo: 444, Hi: 65535}}
			runner := &fakeRunner{}
			a := NewApplier(runner.Run, Options{MitmRedirectPort: 18081, PortFloorDenyRanges: ranges})
			s := subject.FromSandboxUID("u-1")
			other := subject.FromSandboxUID("u-2")
			ctx := context.Background()
			require.NoError(t, a.ApplyDenyFirst(ctx, s, testSlot("u-1", "10.0.0.5")))
			require.NoError(t, a.ApplyDenyFirst(ctx, other, testSlot("u-2", "10.0.0.6")))
			user, err := policy.ParsePolicy(fmt.Sprintf(`{"defaultAction":%q,"egress":[{"action":"allow","ports":[22,443]},{"action":"deny","ports":[80]}]}`, defaultAction))
			require.NoError(t, err)
			effective := policy.MergeAlwaysOverlay(user, []policy.EgressRule{policy.NewPortFloorDenyRule(ranges)}, nil)
			require.NoError(t, a.ApplyPolicy(ctx, s, effective))
			assert.NotContains(t, runner.last(), "1-79", "the platform cap must not be duplicated per subject")
			require.NoError(t, a.Remove(ctx, other))
			script := runner.last()
			floorForward := "add rule inet opensandbox-fast-sandbox dispatch tcp dport { 1-79, 81-442, 444-65535 } drop"
			floorInput := "add rule inet opensandbox-fast-sandbox input ct status dnat tcp dport 18081 ct original proto-dst { 1-79, 81-442, 444-65535 } drop"
			require.Contains(t, script, floorForward)
			require.Contains(t, script, floorInput)
			require.Equal(t, 2, strings.Count(script, "1-79"))
			require.Less(t, strings.Index(script, floorForward), strings.Index(script, "dispatch ip saddr 10.0.0.5 jump"))
			require.Less(t, strings.Index(script, floorInput), strings.Index(script, "input ip saddr 10.0.0.5 tcp dport 18081 ct status dnat jump"))
			require.Contains(t, script, "subj_s_u_1 tcp dport { 80 } drop")
			require.Contains(t, script, "subj_s_u_1_in meta l4proto tcp ct original proto-dst { 22, 443 } accept")
		})
	}
}

// nftMissingObjectError mimics `nft -f -` failing on line with "No such file
// or directory", as DefaultRunner reports it.
func nftMissingObjectError(line string) error {
	return fmt.Errorf("nft apply failed: exit status 1 (output: /dev/stdin:1:1-10: Error: Could not process rule: No such file or directory\n%s\n^^^^^^^^^^)", line)
}

func TestResetRetriesWithoutDeleteWhenTableIsMissing(t *testing.T) {
	deleteLine := "delete table inet " + TableName
	runner := &fakeRunner{fail: func(script string) error {
		if strings.Contains(script, deleteLine) {
			return nftMissingObjectError(deleteLine)
		}
		return nil
	}}
	a := NewApplier(runner.Run)

	if err := a.ApplyReset(context.Background()); err != nil {
		t.Fatalf("ApplyReset: %v", err)
	}
	if runner.count() != 2 {
		t.Fatalf("runs = %d, want the failed batch and one retry", runner.count())
	}
	if strings.Contains(runner.last(), deleteLine) {
		t.Fatalf("retry still deletes the table:\n%s", runner.last())
	}
}

func TestResetDoesNotRetryOtherMissingObjectErrors(t *testing.T) {
	runner := &fakeRunner{fail: func(string) error {
		return nftMissingObjectError("add rule inet " + TableName + " forward jump subj_gone")
	}}
	a := NewApplier(runner.Run)

	if err := a.ApplyReset(context.Background()); err == nil {
		t.Fatal("ApplyReset succeeded, want the batch error")
	}
	if runner.count() != 1 {
		t.Fatalf("runs = %d, want only the failed batch", runner.count())
	}
}
