// Copyright 2026 The OpenSandbox Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"context"
	"errors"
	"fmt"
	"net/netip"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	_ "github.com/alibaba/opensandbox/egress/hooks"
	_ "github.com/alibaba/opensandbox/internal/safego"
	_ "go.uber.org/automaxprocs/maxprocs"

	"github.com/alibaba/opensandbox/egress/pkg/constants"
	"github.com/alibaba/opensandbox/egress/pkg/dnsproxy"
	"github.com/alibaba/opensandbox/egress/pkg/events"
	"github.com/alibaba/opensandbox/egress/pkg/iptables"
	"github.com/alibaba/opensandbox/egress/pkg/log"
	"github.com/alibaba/opensandbox/egress/pkg/mitmproxy"
	"github.com/alibaba/opensandbox/egress/pkg/nftables"
	"github.com/alibaba/opensandbox/egress/pkg/policy"
	"github.com/alibaba/opensandbox/egress/pkg/startup"
	"github.com/alibaba/opensandbox/egress/pkg/telemetry"
	slogger "github.com/alibaba/opensandbox/internal/logger"
	"github.com/alibaba/opensandbox/internal/safego"
	"github.com/alibaba/opensandbox/internal/version"
)

func main() {
	version.EchoVersion("OpenSandbox Egress")

	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	ctx = withLogger(ctx)
	defer log.Logger.Sync()

	// Validate the chained upstream proxy env before profile dispatch: a
	// configured proxy without transparent mitmproxy (and, outside
	// fast-sandbox, without dns+nft enforcement) fails startup instead of
	// being silently ignored.
	profile := strings.TrimSpace(os.Getenv(constants.EnvEgressProfile))
	fsbMode, err := revisionRuntimeStartup(profile)
	if err != nil {
		log.Fatalf("invalid live revision runtime configuration: %v", err)
	}
	startupFSBInterceptionMode = &fsbMode
	if fsbMode.deprecatedAlias {
		log.Warnf("%s and %s are deprecated for Fast Sandbox TLS admission; use %s=credential-bound", constants.EnvExperimentalRevisionRuntime, constants.EnvExperimentalFSBTLSAdmission, constants.EnvFSBInterceptionMode)
	}
	if _, present := os.LookupEnv(constants.EnvMitmproxyPassthroughHosts); present &&
		(profile == constants.ProfileFastSandbox || !constants.IsTruthy(os.Getenv(constants.EnvExperimentalRevisionRuntime))) {
		log.Fatalf("invalid %s configuration: requires sidecar live revision runtime", constants.EnvMitmproxyPassthroughHosts)
	}

	upstreamSpec, err := upstreamProxySpecForProfile(profile)
	if err != nil {
		log.Fatalf("invalid upstream proxy configuration: %v", err)
	}

	// Fast Sandbox profile: multi-sandbox control plane driven by the
	// Sandbox Actions Handler protocol. Sidecar stays the default; the two
	// profiles are mutually exclusive deployment forms.
	if profile == constants.ProfileFastSandbox {
		runFastSandboxProfile(ctx, upstreamSpec)
		return
	}

	quarantineOwner, err := newRevisionQuarantine()
	if err != nil {
		log.Fatalf("experimental runtime containment: %v", err)
	}
	if quarantineOwner != nil {
		defer quarantineOwner.target.Close()
	}

	// Reject unsupported experimental storage before policy loading or network
	// setup. Fast Sandbox dispatched above does not use this sidecar store.
	if constants.IsTruthy(os.Getenv(constants.EnvExperimentalRevisionRuntime)) {
		if path := strings.TrimSpace(os.Getenv(constants.EnvEgressPolicyFile)); path != "" {
			if _, err := policy.NewAtomicPolicyFile(path); err != nil {
				log.Fatalf("invalid experimental policy storage: %v", err)
			}
		}
	}

	// Erase any stale mitmproxy CA left on the shared volume by a previous
	// egress generation so the agent's bootstrap wait-loop blocks for this
	// generation's export. See PurgeStaleExportedCA / upstream issue #1370.
	mitmproxy.PurgeStaleExportedCA()

	otelShutdown, err := telemetry.Init(ctx)
	if err != nil {
		log.Warnf("OpenTelemetry metrics disabled (continuing without OTLP): %v", err)
		otelShutdown = nil
	}
	if otelShutdown != nil {
		defer func() {
			shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer shutdownCancel()
			_ = otelShutdown(shutdownCtx)
		}()
	}

	initialRules, _, err := policy.LoadInitialPolicyDetailed(os.Getenv(constants.EnvEgressPolicyFile), constants.EnvEgressRules)
	if err != nil {
		log.Fatalf("failed to load initial egress policy: %v", err)
	}
	logEgressLoaded(initialRules)

	alwaysDeny, alwaysAllow, err := policy.LoadAlwaysRuleFiles()
	if err != nil {
		log.Fatalf("failed to load always allow/deny rule files: %v", err)
	}
	alwaysAllow = withTelemetryAllow(alwaysAllow)

	allowIPs := allowIps()
	mode := parseMode()
	log.Infof("enforcement mode: %s", mode)

	// upstreamSpec was already validated at startup; it scopes the infra nft
	// exception and lets DNS exempt the proxy hostname from sandbox policy
	// without feeding the allow sets.
	nftMgr, err := createNftManager(mode, upstreamSpec)
	if err != nil {
		log.Fatalf("nftables options: %v", err)
	}
	proxy, err := dnsproxy.New(initialRules, "", alwaysDeny, alwaysAllow)
	if err != nil {
		log.Fatalf("failed to init dns proxy: %v", err)
	}
	if upstreamSpec != nil {
		if _, err := netip.ParseAddr(upstreamSpec.Host); err != nil {
			// Hostname endpoint: mitmdump resolves it through the dnsproxy, so
			// exempt it from sandbox policy and feed answers to the uid-scoped
			// nft set instead of the sandbox allow sets.
			host := upstreamSpec.Host
			proxy.SetInfraDomain(host, func(domain string, ips []nftables.ResolvedIP) {
				if nftMgr == nil {
					return
				}
				addCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer cancel()
				if err := nftMgr.AddUpstreamProxyIPs(addCtx, ips); err != nil && !errors.Is(err, nftables.ErrQuiesced) {
					log.Warnf("upstream proxy: nft update for %q failed: %v", domain, err)
				}
			})
			log.Infof("upstream proxy: registered infra DNS domain %q (uid-scoped nft only)", host)
		}
	}
	if err := proxy.Start(ctx); err != nil {
		log.Fatalf("failed to start dns proxy: %v", err)
	}
	log.Infof("dns proxy started on 127.0.0.1:15353")

	logSkipPatterns, err := policy.LoadLogSkipFile()
	if err != nil {
		log.Fatalf("failed to load outbound log skip file: %v", err)
	}
	if len(logSkipPatterns) > 0 {
		proxy.SetLogSkip(logSkipPatterns)
		log.Infof("loaded %d outbound log skip pattern(s) from /var/egress/rules/log_skip.always", len(logSkipPatterns))
	}

	var blockedBroadcaster *events.Broadcaster
	if blockWebhookURL := strings.TrimSpace(os.Getenv(constants.EnvBlockedWebhook)); blockWebhookURL != "" {
		blockedBroadcaster = events.NewBroadcaster(context.WithoutCancel(ctx), events.BroadcasterConfig{QueueSize: 256})
		blockedBroadcaster.AddSubscriber(events.NewWebhookSubscriber(blockWebhookURL))
		proxy.SetBlockedBroadcaster(blockedBroadcaster)
		defer blockedBroadcaster.Close()
		log.Infof("denied hostname webhook enabled")
	}

	exemptDst := dnsproxy.ParseNameserverExemptList()
	if len(exemptDst) > 0 {
		log.Infof("nameserver exempt list: %v (proxy upstream in this list will not set SO_MARK)", exemptDst)
	}
	if err := iptables.SetupRedirect(15353, exemptDst); err != nil {
		log.Fatalf("failed to install iptables redirect: %v", err)
	}
	log.Infof("iptables redirect configured (OUTPUT 53 -> 15353) with SO_MARK bypass for proxy upstream traffic")

	setupNft(ctx, nftMgr, initialRules, proxy, allowIPs, alwaysDeny, alwaysAllow)

	httpAddr := envOrDefault(constants.EnvEgressHTTPAddr, constants.DefaultEgressServerAddr)
	mitmGate := mitmproxy.NewHealthGate()
	policySrv, policyHandler, err := startPolicyServer(proxy, nftMgr, mode, httpAddr, os.Getenv(constants.EnvEgressToken), allowIPs, os.Getenv(constants.EnvEgressPolicyFile), alwaysDeny, alwaysAllow, mitmGate, quarantineOwner)
	if err != nil {
		log.Fatalf("failed to start policy server: %v", err)
	}
	log.Infof("policy server listening on %s (POST /policy)", httpAddr)

	mitm, err := startMitmproxyTransparentIfEnabled(ctx, policyHandler)
	if err != nil {
		log.Fatalf("mitmproxy transparent: %v", err)
	}
	if !constants.IsTruthy(os.Getenv(constants.EnvExperimentalRevisionRuntime)) {
		mitmGate.MarkStackReady()
	}
	if constants.IsTruthy(os.Getenv(constants.EnvExperimentalRevisionRuntime)) && mitm != nil {
		// Attach the live mitmdump lifecycle owner before serving revision-gated
		// Vault writes; until then such writes fail closed with 503.
		policyHandler.setRevisionMitm(mitm)
	}
	if mitm != nil {
		mitm.watchMitmproxy(ctx, mitmGate)
	}

	if err := startup.RunPost(ctx); err != nil {
		log.Errorf("startup hooks (post) error: %v", err)
	}

	waitForShutdown(ctx, proxy, policySrv, exemptDst, nftMgr, mitm, blockedBroadcaster, policyHandler)
}

// validateRevisionRuntimeStartup runs before profile dispatch or network setup.
// Kept for startup-focused callers; main retains the resolved mode for launch.
func validateRevisionRuntimeStartup(profile string) error {
	_, err := revisionRuntimeStartup(profile)
	return err
}

func revisionRuntimeStartup(profile string) (fastSandboxInterceptionMode, error) {
	mode, err := resolveFastSandboxInterceptionMode(profile)
	if err != nil {
		return mode, err
	}
	if profile == constants.ProfileFastSandbox {
		return mode, validateFastSandboxInterception(mode)
	}
	if !constants.IsTruthy(os.Getenv(constants.EnvExperimentalRevisionRuntime)) {
		return mode, nil
	}
	ports, err := constants.BuildMitmproxyPortList(os.Getenv(constants.EnvMitmproxyExtraPorts))
	if err != nil {
		return mode, fmt.Errorf("invalid %s for live revision runtime", constants.EnvMitmproxyExtraPorts)
	}
	if ports != constants.MitmproxyBasePorts {
		return mode, fmt.Errorf("%s is not supported with %s", constants.EnvMitmproxyExtraPorts, constants.EnvExperimentalRevisionRuntime)
	}
	return mode, nil
}

func withLogger(ctx context.Context) context.Context {
	level := envOrDefault(constants.EnvEgressLogLevel, "info")
	cfg := slogger.Config{Level: level}
	base := slogger.MustNew(cfg)
	// Baseline log fields (e.g. sandbox_id, OPENSANDBOX_EGRESS_METRICS_EXTRA_ATTRS) for every line.
	if extra := telemetry.EgressLogFields(); len(extra) > 0 {
		base = base.With(extra...)
	}
	logger := base.Named("opensandbox.egress")
	safego.InitPanicLogger(ctx, logger)
	return log.WithLogger(ctx, logger)
}

func envOrDefault(key, defaultVal string) string {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		return v
	}
	return defaultVal
}

func containsAddr(addrs []netip.Addr, a netip.Addr) bool {
	for _, x := range addrs {
		if x == a {
			return true
		}
	}
	return false
}

func parseMode() string {
	raw := os.Getenv(constants.EnvEgressMode)
	normalized, err := constants.ParseEgressMode(raw)
	if err != nil {
		log.Warnf("invalid %s=%q: %v; falling back to %s", constants.EnvEgressMode, raw, err, constants.PolicyDnsOnly)
		return constants.PolicyDnsOnly
	}
	return normalized
}
