// Copyright 2026 The OpenSandbox Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"context"
	"errors"
	"fmt"
	"net/netip"
	"os"
	"strings"
	"time"

	"github.com/alibaba/opensandbox/egress/pkg/constants"
	"github.com/alibaba/opensandbox/egress/pkg/dnsproxy"
	"github.com/alibaba/opensandbox/egress/pkg/log"
	"github.com/alibaba/opensandbox/egress/pkg/mitmproxy"
	"github.com/alibaba/opensandbox/egress/pkg/nftables"
	"github.com/alibaba/opensandbox/egress/pkg/policy"
	"github.com/alibaba/opensandbox/egress/pkg/telemetry"
)

// createNftManager is non-nil only when mode includes the nft token (e.g. dns+nft).
func createNftManager(mode string, upstream *mitmproxy.UpstreamProxySpec) (nftApplier, error) {
	if !constants.ModeUsesNft(mode) {
		return nil, nil
	}
	opts, err := parseNftOptions(upstream)
	if err != nil {
		return nil, err
	}
	return nftables.NewManagerWithOptions(opts), nil
}

// setupNft: apply static policy to nft, then wire allowed DNS answers to AddResolvedDomain (dynamic allow sets).
// nameserverIPs and always-deny/allow follow the same merge rules as the policy API (MergeAlwaysOverlay + WithExtraAllowIPs).
func setupNft(ctx context.Context, nftMgr nftApplier, initialPolicy *policy.NetworkPolicy, proxy *dnsproxy.Proxy, nameserverIPs []netip.Addr, alwaysDeny, alwaysAllow []policy.EgressRule) {
	if nftMgr == nil {
		log.Warnf("nftables disabled (dns-only mode)")
		return
	}

	log.Infof("applying nftables static policy (dns+nft mode) with %d nameserver IP(s) merged into allow set", len(nameserverIPs))
	merged := policy.MergeAlwaysOverlay(initialPolicy, alwaysDeny, alwaysAllow)
	policyWithNS := merged.WithExtraAllowIPs(nameserverIPs)
	if err := nftMgr.ApplyStatic(ctx, policyWithNS); err != nil {
		// ApplyStatic recorded the failure, but Fatalf calls os.Exit and the periodic
		// reader would never export it, nor would main's deferred shutdown run. Flush
		// first, so the one sample explaining why the sidecar died actually leaves.
		flushCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		if flushErr := telemetry.ForceFlush(flushCtx); flushErr != nil {
			log.Warnf("failed to flush telemetry before exit: %v", flushErr)
		}
		cancel()
		log.Fatalf("nftables static apply failed: %v", err)
	}
	log.Infof("nftables static policy applied (table inet opensandbox); DNS-resolved IPs will be added to dynamic allow sets")
	proxy.SetOnResolved(func(domain string, ips []nftables.ResolvedIP) {
		addCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := nftMgr.AddResolvedDomain(addCtx, domain, ips); err != nil && !errors.Is(err, nftables.ErrQuiesced) {
			log.Warnf("[dns] record resolved domain %q failed: %v", domain, err)
		}
	})
	nftMgr.StartConnectionRefresh(ctx)
	nftMgr.StartDomainRefresh(ctx, proxy.ResolveDomain)
}

// parseDoHBlocklist parses the comma-separated OPENSANDBOX_EGRESS_DOH_BLOCKLIST
// value (IP or CIDR entries) into v4/v6 lists. Invalid entries are logged and
// skipped. Shared by the sidecar and fast-sandbox profiles so both enforce the same
// DoH-443 semantics.
func parseDoHBlocklist(raw string) (v4, v6 []string) {
	for _, p := range strings.Split(raw, ",") {
		target := strings.TrimSpace(p)
		if target == "" {
			continue
		}
		if addr, err := netip.ParseAddr(target); err == nil {
			if addr.Is4() {
				v4 = append(v4, target)
			} else if addr.Is6() {
				v6 = append(v6, target)
			}
			continue
		}
		if prefix, err := netip.ParsePrefix(target); err == nil {
			if prefix.Addr().Is4() {
				v4 = append(v4, target)
			} else if prefix.Addr().Is6() {
				v6 = append(v6, target)
			}
			continue
		}
		log.Warnf("ignoring invalid DoH blocklist entry: %s", target)
	}
	return v4, v6
}

func parseNftOptions(upstream *mitmproxy.UpstreamProxySpec) (nftables.Options, error) {
	opts := nftables.Options{
		BlockDoT:              true,
		QuiesceOnApplyFailure: constants.IsTruthy(os.Getenv(constants.EnvExperimentalRevisionRuntime)),
	}
	// Transparent MITM: exempt the REDIRECT target dport ahead of port-scoped
	// rules (issue #2423). Same port derivation as startMitmproxyTransparentIfEnabled.
	if constants.IsTruthy(os.Getenv(constants.EnvMitmproxyTransparent)) {
		opts.MitmRedirectPort = constants.EnvIntOrDefault(constants.EnvMitmproxyPort, constants.DefaultMitmproxyPort)
	}
	if constants.IsTruthy(os.Getenv(constants.EnvBlockDoH443)) {
		opts.BlockDoH443 = true
	}
	if raw := os.Getenv(constants.EnvDoHBlocklist); strings.TrimSpace(raw) != "" {
		opts.DoHBlocklistV4, opts.DoHBlocklistV6 = parseDoHBlocklist(raw)
	}
	if upstream != nil {
		uid, _, _, err := mitmproxy.LookupUser(mitmproxy.RunAsUser)
		if err != nil {
			return opts, fmt.Errorf("lookup user %q for upstream proxy nft scope: %w", mitmproxy.RunAsUser, err)
		}
		ep := &nftables.UpstreamProxyEndpoint{Port: upstream.Port, UID: uid}
		if ip, err := netip.ParseAddr(upstream.Host); err == nil {
			ep.IPs = []netip.Addr{ip.Unmap()}
		}
		opts.UpstreamProxy = ep
	}
	return opts, nil
}
