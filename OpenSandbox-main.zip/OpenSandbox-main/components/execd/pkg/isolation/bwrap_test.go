// Copyright 2026 The OpenSandbox Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//go:build linux

package isolation

import (
	"os/exec"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestBuildArgv_NamespaceFlags(t *testing.T) {
	tests := []struct {
		name     string
		shareNet bool
		want     string // substring that must appear
		dontWant string // substring that must NOT appear
	}{
		{"share_net=true (default)", true, "", "--unshare-net"},
		{"share_net=false", false, "--unshare-net", ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			opts := basicWrapOpts()
			opts.ShareNet = tt.shareNet
			argv, err := buildArgv(opts, "")
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			s := strings.Join(argv, " ")
			if tt.want != "" && !strings.Contains(s, tt.want) {
				t.Errorf("argv missing %q:\n  %s", tt.want, s)
			}
			if tt.dontWant != "" && strings.Contains(s, tt.dontWant) {
				t.Errorf("argv contains %q but should not:\n  %s", tt.dontWant, s)
			}
		})
	}
}

func TestBuildArgv_TmpSegment(t *testing.T) {
	tests := []struct {
		profile Profile
		want    string
		dont    string
	}{
		{ProfileStrict, "--tmpfs /tmp", "--bind /tmp /tmp"},
		{ProfileBalanced, "--bind /tmp /tmp", "--tmpfs /tmp"},
	}

	for _, tt := range tests {
		t.Run(string(tt.profile), func(t *testing.T) {
			opts := basicWrapOpts()
			opts.Profile = tt.profile
			argv, err := buildArgv(opts, "")
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			s := strings.Join(argv, " ")
			if !strings.Contains(s, tt.want) {
				t.Errorf("%s: missing %q:\n  %s", tt.profile, tt.want, s)
			}
			if tt.dont != "" && strings.Contains(s, tt.dont) {
				t.Errorf("%s: should not contain %q:\n  %s", tt.profile, tt.dont, s)
			}
		})
	}
}

func TestBuildArgv_TmpDir(t *testing.T) {
	t.Run("host_backed_bind_replaces_profile_segment", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Profile = ProfileStrict
		opts.TmpDir = "/var/lib/execd/isolation/abc/tmp"
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--bind /var/lib/execd/isolation/abc/tmp /tmp") {
			t.Errorf("missing host-backed /tmp bind:\n  %s", s)
		}
		if strings.Contains(s, "--tmpfs /tmp") {
			t.Errorf("profile tmpfs segment must be replaced:\n  %s", s)
		}
	})

	t.Run("overlay_on_tmp_skips_host_bind", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Profile = ProfileStrict
		opts.TmpDir = "/var/lib/execd/isolation/abc/tmp"
		opts.Overlays = append(opts.Overlays, OverlaySpec{Path: "/tmp", Mode: WorkspaceRW})
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		s := strings.Join(argv, " ")
		if strings.Contains(s, "/var/lib/execd/isolation/abc/tmp") {
			t.Errorf("host-backed /tmp bind must be skipped when an overlay covers /tmp:\n  %s", s)
		}
		if !strings.Contains(s, "--bind /tmp /tmp") {
			t.Errorf("overlay segment missing:\n  %s", s)
		}
	})

	t.Run("relative_tmp_dir_rejected", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.TmpDir = "relative/tmp"
		if _, err := buildArgv(opts, ""); err == nil {
			t.Error("expected error for relative tmp dir")
		}
	})
}

func TestBuildArgv_WorkspaceSegment(t *testing.T) {
	ws := func(mode WorkspaceMode) WrapOptions {
		opts := basicWrapOpts()
		opts.Overlays[0].Mode = mode
		return opts
	}

	t.Run("rw", func(t *testing.T) {
		argv, err := buildArgv(ws(WorkspaceRW), "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--bind /workspace /workspace") {
			t.Error(s)
		}
	})

	t.Run("ro", func(t *testing.T) {
		argv, err := buildArgv(ws(WorkspaceRO), "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--ro-bind /workspace /workspace") {
			t.Error(s)
		}
	})

	t.Run("overlay_with_persist", func(t *testing.T) {
		opts := ws(WorkspaceOverlay)
		opts.Overlays[0].UpperDir = "/var/lib/execd/isolation/abc/upper"
		opts.Overlays[0].WorkDir = "/var/lib/execd/isolation/abc/work"
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		for _, want := range []string{
			"--overlay",
			"/workspace",
			"/var/lib/execd/isolation/abc/upper",
			"/var/lib/execd/isolation/abc/work",
		} {
			if !strings.Contains(s, want) {
				t.Errorf("missing %q", want)
			}
		}
	})

	t.Run("overlay_without_persist_tmpfs", func(t *testing.T) {
		opts := ws(WorkspaceOverlay)
		opts.Overlays[0].UpperDir = "" // tmpfs upper
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--overlay-src") {
			t.Error("missing --overlay-src")
		}
	})

	t.Run("shallowest_valid_upperdir_accepted", func(t *testing.T) {
		// <root>/<session>/upper (depth 3) derives a non-root upper root
		// and must be accepted; anything shallower is rejected by
		// validateWrapOptions.
		opts := ws(WorkspaceOverlay)
		opts.Overlays[0].UpperDir = "/upper-root/session/upper"
		_, err := buildArgv(opts, "")
		require.NoError(t, err)
	})
}

func TestOverlaysCoverPath(t *testing.T) {
	overlays := []OverlaySpec{
		{Path: "/", Mode: WorkspaceOverlay},
		{Path: "/data", Mode: WorkspaceOverlay},
	}

	assert.True(t, OverlaysCoverPath(overlays, "/tmp"),
		"a / overlay is an ancestor of /tmp and covers it")
	assert.True(t, OverlaysCoverPath(overlays, "/data/sub"),
		"an exact overlay path covers its own subtree")
	assert.False(t, OverlaysCoverPath(overlays[1:], "/tmp"),
		"a sibling overlay must not cover /tmp")
}

func TestBuildArgv_MultiOverlay(t *testing.T) {
	t.Run("nested_overlays_ordered_shallow_first", func(t *testing.T) {
		// Caller lists the deep workspace overlay first; argv must emit the
		// root overlay before it so the nested mount shadows the root.
		opts := basicWrapOpts()
		opts.Overlays = []OverlaySpec{
			{Path: "/workspace", Mode: WorkspaceOverlay},
			{
				Path:     "/",
				Mode:     WorkspaceOverlay,
				UpperDir: "/var/lib/execd/isolation/abc/root-upper",
			},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)

		rootIdx := indexArgvSequence(argv,
			"--overlay-src", "/", "--overlay",
			"/var/lib/execd/isolation/abc/root-upper",
			"/var/lib/execd/isolation/abc/root-upper-work", "/")
		if rootIdx < 0 {
			t.Fatalf("root overlay segment missing: %v", argv)
		}
		wsIdx := indexArgvSequence(argv,
			"--overlay-src", "/workspace", "--tmp-overlay", "/workspace")
		if wsIdx < 0 {
			t.Fatalf("workspace overlay segment missing: %v", argv)
		}
		if rootIdx > wsIdx {
			t.Errorf("root overlay must precede nested /workspace overlay: %v", argv)
		}
	})

	t.Run("mixed_modes", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Overlays = []OverlaySpec{
			{Path: "/etc/config", Mode: WorkspaceRO},
			{Path: "/data", Mode: WorkspaceOverlay},
			{Path: "/mnt/project", Mode: WorkspaceRW},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")
		for _, want := range []string{
			"--ro-bind /etc/config /etc/config",
			"--overlay-src /data --tmp-overlay /data",
			"--bind /mnt/project /mnt/project",
		} {
			assert.Contains(t, s, want)
		}
	})

	t.Run("overlay_on_tmp_skips_tmp_segment", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Profile = ProfileStrict
		opts.Overlays = []OverlaySpec{{Path: "/tmp", Mode: WorkspaceRW}}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		assert.NotContains(t, strings.Join(argv, " "), "--tmpfs /tmp",
			"an overlay on /tmp replaces the /tmp tmpfs segment")
	})

	t.Run("root_overlay_covers_tmp_segment", func(t *testing.T) {
		// A / overlay shadows every earlier mount in its subtree, so the
		// /tmp segment would be dead weight; it must be skipped.
		opts := basicWrapOpts()
		opts.Profile = ProfileStrict
		opts.Overlays = []OverlaySpec{
			{Path: "/", Mode: WorkspaceOverlay, UpperDir: "/var/lib/execd/isolation/abc/root-upper"},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		assert.NotContains(t, strings.Join(argv, " "), "--tmpfs /tmp",
			"a / overlay covers /tmp as its ancestor")
	})

	t.Run("sibling_overlay_keeps_tmp_segment", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Profile = ProfileStrict
		opts.Overlays = []OverlaySpec{
			{Path: "/data", Mode: WorkspaceOverlay, UpperDir: "/var/lib/execd/isolation/abc/upper"},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		assert.Contains(t, strings.Join(argv, " "), "--tmpfs /tmp",
			"an overlay outside /tmp must not suppress the /tmp segment")
	})

	t.Run("hides_distinct_upper_roots_once", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Overlays = []OverlaySpec{
			{
				Path:     "/",
				Mode:     WorkspaceOverlay,
				UpperDir: "/var/lib/execd/isolation/abc/root-upper",
			},
			{
				Path:     "/workspace",
				Mode:     WorkspaceOverlay,
				UpperDir: "/var/lib/execd/isolation/abc/upper-1",
			},
			{
				Path:     "/data",
				Mode:     WorkspaceOverlay,
				UpperDir: "/var/lib/execd/other/session/root-upper",
			},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)

		// Collect every --tmpfs target. Pairs sharing a session dir collapse
		// to one hidden upper root; a distinct session dir adds another.
		hidden := make(map[string]int)
		for i, arg := range argv {
			if arg == "--tmpfs" && i+1 < len(argv) &&
				strings.HasPrefix(argv[i+1], "/var/lib/execd") {
				hidden[argv[i+1]]++
			}
		}
		assert.Equal(t, map[string]int{
			"/var/lib/execd/isolation": 1,
			"/var/lib/execd/other":     1,
		}, hidden)
	})

	t.Run("tmpfs_uppers_hide_nothing", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Overlays = []OverlaySpec{
			{Path: "/workspace", Mode: WorkspaceOverlay},
			{Path: "/data", Mode: WorkspaceOverlay},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		assert.NotContains(t, strings.Join(argv, " "), "--tmpfs /var/lib",
			"ephemeral overlays have no host upper directory to hide")
	})
}

func TestBuildArgv_EnvPassthrough(t *testing.T) {
	t.Run("deny_with_keys", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.EnvPassthrough = EnvSpec{Mode: EnvModeDeny, Keys: []string{"SECRET", "TOKEN"}}
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--unsetenv SECRET") {
			t.Error(s)
		}
		if !strings.Contains(s, "--unsetenv TOKEN") {
			t.Error(s)
		}
	})

	t.Run("allow_with_clearenv", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.EnvPassthrough = EnvSpec{Mode: EnvModeAllow, Keys: []string{"PATH", "HOME"}}
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--clearenv") {
			t.Error("missing --clearenv")
		}
	})

	t.Run("empty_mode_strips_execd_config_env", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.EnvPassthrough = EnvSpec{} // empty mode
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		// Default mode must always strip execd's own configuration env,
		// but must not emit --clearenv (user business env is untouched).
		if strings.Contains(s, "--clearenv") {
			t.Error("empty mode must not use --clearenv")
		}
		for _, k := range execdConfigEnvBlacklist {
			if !strings.Contains(s, "--unsetenv "+k) {
				t.Errorf("empty mode must --unsetenv %s, argv:\n  %s", k, s)
			}
		}
	})
}

func TestBuildArgv_ExecdConfigEnvAlwaysStripped(t *testing.T) {
	tests := []struct {
		name string
		spec EnvSpec
	}{
		{"empty_mode", EnvSpec{}},
		{"deny_empty_keys", EnvSpec{Mode: EnvModeDeny}},
		{"deny_with_keys", EnvSpec{Mode: EnvModeDeny, Keys: []string{"FOO"}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			opts := basicWrapOpts()
			opts.EnvPassthrough = tt.spec
			argv, err := buildArgv(opts, "")
			require.NoError(t, err)
			s := strings.Join(argv, " ")
			for _, k := range execdConfigEnvBlacklist {
				assert.Contains(t, s, "--unsetenv "+k,
					"%s: execd config env %s must be unset", tt.name, k)
			}
		})
	}

	t.Run("allow_mode_uses_clearenv_and_refuses_reinjection", func(t *testing.T) {
		// Even if the caller explicitly allow-lists an execd config env,
		// we must not re-inject it via --setenv.
		t.Setenv("EXECD_ACCESS_TOKEN", "supersecret")
		t.Setenv("JUPYTER_TOKEN", "jt")

		opts := basicWrapOpts()
		opts.EnvPassthrough = EnvSpec{
			Mode: EnvModeAllow,
			Keys: []string{"EXECD_ACCESS_TOKEN", "JUPYTER_TOKEN", "PATH"},
		}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")
		assert.Contains(t, s, "--clearenv")
		assert.NotContains(t, s, "supersecret",
			"allow mode must not re-inject execd config env value")
		assert.NotContains(t, s, "--setenv EXECD_ACCESS_TOKEN")
		assert.NotContains(t, s, "--setenv JUPYTER_TOKEN")
	})
}

func TestBuildArgv_ExtraWritable(t *testing.T) {
	opts := basicWrapOpts()
	opts.ExtraWritable = []string{"/data", "/tmp/custom"}
	argv, err := buildArgv(opts, "")
	if err != nil {
		t.Fatal(err)
	}
	s := strings.Join(argv, " ")

	for _, p := range opts.ExtraWritable {
		// Each writable path generates "--bind $p $p"
		if strings.Count(s, p) < 2 {
			t.Errorf("missing bind for %q in:\n  %s", p, s)
		}
	}
}

func TestBuildArgv_Binds(t *testing.T) {
	t.Run("rw_src_to_dest", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Binds = []BindMount{{Source: "/host/data", Dest: "/container/data"}}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")
		assert.Contains(t, s, "--bind /host/data /container/data")
	})

	t.Run("readonly_uses_ro_bind", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Binds = []BindMount{{Source: "/host/ro", Dest: "/mnt/ro", ReadOnly: true}}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")
		assert.Contains(t, s, "--ro-bind /host/ro /mnt/ro")
	})

	t.Run("empty_dest_defaults_to_source", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Binds = []BindMount{{Source: "/host/same"}}
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")
		assert.Contains(t, s, "--bind /host/same /host/same")
	})

	t.Run("validation_empty_source", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Binds = []BindMount{{Dest: "/mnt/x"}}
		_, err := buildArgv(opts, "")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "bind.source is required")
	})

	t.Run("validation_relative_source", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Binds = []BindMount{{Source: "relative/path"}}
		_, err := buildArgv(opts, "")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "must be an absolute path")
	})

	t.Run("validation_relative_dest", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Binds = []BindMount{{Source: "/host/a", Dest: "rel/dest"}}
		_, err := buildArgv(opts, "")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "must be an absolute path")
	})
}

func TestBuildArgv_Setpriv(t *testing.T) {
	t.Run("default_uid_gid", func(t *testing.T) {
		opts := basicWrapOpts()
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "setpriv") {
			t.Error("missing setpriv")
		}
		if !strings.Contains(s, "--clear-groups") {
			t.Error("missing --clear-groups")
		}
	})

	t.Run("explicit_uid_gid", func(t *testing.T) {
		opts := basicWrapOpts()
		u, g := uint32(1001), uint32(1002)
		opts.Uid = &u
		opts.Gid = &g
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatal(err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--reuid=1001") {
			t.Error("missing --reuid=1001")
		}
		if !strings.Contains(s, "--regid=1002") {
			t.Error("missing --regid=1002")
		}
	})
}

func TestBuildArgv_Userns(t *testing.T) {
	t.Run("userns_mode_uses_unshare_user", func(t *testing.T) {
		opts := basicWrapOpts()
		u, g := uint32(1000), uint32(1000)
		opts.Uid = &u
		opts.Gid = &g
		opts.UidMode = UidModeUserns
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")

		assert.Contains(t, s, "--unshare-user", "userns mode must include --unshare-user")
		assert.Contains(t, s, "--disable-userns", "userns mode must include --disable-userns")
		assert.Contains(t, s, "--uid 1000", "userns mode must include --uid")
		assert.Contains(t, s, "--gid 1000", "userns mode must include --gid")
	})

	t.Run("userns_mode_setuid_bwrap_skips_disable_userns", func(t *testing.T) {
		// --disable-userns is unsupported by the setuid build of bwrap.
		bwrapIsSetuid = true
		defer func() { bwrapIsSetuid = false }()

		opts := basicWrapOpts()
		opts.UidMode = UidModeUserns
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")

		assert.Contains(t, s, "--unshare-user", "userns mode must still include --unshare-user")
		assert.NotContains(t, s, "--disable-userns", "setuid bwrap must not include --disable-userns")
	})

	t.Run("userns_mode_no_setpriv", func(t *testing.T) {
		opts := basicWrapOpts()
		u, g := uint32(1000), uint32(1000)
		opts.Uid = &u
		opts.Gid = &g
		opts.UidMode = UidModeUserns
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")

		assert.NotContains(t, s, "setpriv", "userns mode must not include setpriv")
		assert.NotContains(t, s, "--reuid", "userns mode must not include --reuid")
		assert.NotContains(t, s, "--regid", "userns mode must not include --regid")
	})

	t.Run("setpriv_mode_no_unshare_user", func(t *testing.T) {
		opts := basicWrapOpts()
		u, g := uint32(1000), uint32(1000)
		opts.Uid = &u
		opts.Gid = &g
		opts.UidMode = UidModeSetpriv
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")

		assert.NotContains(t, s, "--unshare-user", "setpriv mode must not include --unshare-user")
		assert.NotContains(t, s, "--disable-userns", "setpriv mode must not include --disable-userns")
		assert.Contains(t, s, "setpriv", "setpriv mode must include setpriv")
		assert.Contains(t, s, "--reuid=1000", "setpriv mode must include --reuid")
		assert.Contains(t, s, "--regid=1000", "setpriv mode must include --regid")
	})

	t.Run("empty_uid_mode_defaults_to_setpriv", func(t *testing.T) {
		opts := basicWrapOpts()
		u, g := uint32(1000), uint32(1000)
		opts.Uid = &u
		opts.Gid = &g
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)
		s := strings.Join(argv, " ")

		assert.NotContains(t, s, "--unshare-user")
		assert.Contains(t, s, "setpriv")
	})

	t.Run("userns_namespace_flag_order", func(t *testing.T) {
		opts := basicWrapOpts()
		u := uint32(1000)
		opts.Uid = &u
		opts.UidMode = UidModeUserns
		argv, err := buildArgv(opts, "")
		require.NoError(t, err)

		// --unshare-user must come before --unshare-pid (both in segment 1).
		idxUser := indexOf(argv, "--unshare-user")
		idxPid := indexOf(argv, "--unshare-pid")
		assert.Greater(t, idxPid, idxUser,
			"--unshare-user should appear before --unshare-pid")

		// --uid/--gid should come after --unshare-ipc (still in segment 1),
		// before segment 2 (--ro-bind).
		idxUid := indexOf(argv, "--uid")
		idxRoBind := indexOf(argv, "--ro-bind")
		assert.Greater(t, idxRoBind, idxUid,
			"--uid should appear before --ro-bind (segment 2)")
	})
}

func TestBuildArgv_Validation_UidMode(t *testing.T) {
	opts := basicWrapOpts()
	opts.UidMode = "bogus"
	_, err := buildArgv(opts, "")
	require.Error(t, err)
	assert.Contains(t, err.Error(), "unknown uid mode")
}

func TestBuildArgv_Seccomp(t *testing.T) {
	opts := basicWrapOpts()
	argv, err := buildArgv(opts, "3") // fd number passed to --seccomp
	require.NoError(t, err)
	s := strings.Join(argv, " ")
	assert.Contains(t, s, "--seccomp 3", "missing seccomp fd")
}

func TestBuildArgv_SegmentOrder(t *testing.T) {
	opts := basicWrapOpts()
	opts.Profile = ProfileStrict
	opts.Overlays[0].Mode = WorkspaceOverlay
	opts.Overlays[0].UpperDir = "/var/lib/execd/isolation/abc/upper"
	opts.ExtraWritable = []string{"/data"}
	opts.EnvPassthrough = EnvSpec{Mode: EnvModeDeny, Keys: []string{"TOKEN"}}

	argv, err := buildArgv(opts, "3") // fd number passed to --seccomp
	if err != nil {
		t.Fatal(err)
	}

	// Expected segment order. Caller-controlled mounts (overlays, upper-root
	// hiding, extra writable, binds) come first; the trusted base mounts
	// (/run, /dev, procfs) follow so none of them can shadow the others.
	// We track by scanning argv for each marker and comparing the index of
	// the first segment element.
	type seg struct {
		label string
		match string // single argv element
	}
	order := []seg{
		{"1.ns", "--unshare-pid"},
		{"2.rootfs", "--ro-bind"},
		{"3.tmp", "/tmp"},
		{"4.overlays", "--overlay-src"},
		{"5.extra_writable", "--bind"},
		{"6.run", "/run"},
		{"7.dev", "--dev"},
		{"8.proc", "--proc"},
		{"9.env", "--unsetenv"},
		{"10.seccomp", "--seccomp"},
		{"11.setpriv", "setpriv"},
	}

	lastIdx := -1
	for _, s := range order {
		idx := indexOf(argv, s.match)
		if idx < 0 {
			t.Errorf("segment %s (%q) not found in argv:\n  %v", s.label, s.match, argv)
			continue
		}
		if idx <= lastIdx {
			t.Errorf("segment %s (%q) at %d: should be after index %d", s.label, s.match, idx, lastIdx)
		}
		lastIdx = idx
	}
}

func TestBuildArgv_SegmentOrder_Userns(t *testing.T) {
	opts := basicWrapOpts()
	opts.Profile = ProfileStrict
	opts.Overlays[0].Mode = WorkspaceOverlay
	opts.Overlays[0].UpperDir = "/var/lib/execd/isolation/abc/upper"
	opts.ExtraWritable = []string{"/data"}
	opts.EnvPassthrough = EnvSpec{Mode: EnvModeDeny, Keys: []string{"TOKEN"}}
	u := uint32(1000)
	opts.Uid = &u
	opts.UidMode = UidModeUserns

	argv, err := buildArgv(opts, "3")
	require.NoError(t, err)

	type seg struct {
		label string
		match string
	}
	// In userns mode: --unshare-user comes first, no setpriv at the end.
	// Trusted base mounts (/run, /dev, procfs) follow the caller-controlled
	// overlay segments.
	order := []seg{
		{"1.ns.userns", "--unshare-user"},
		{"1.ns.pid", "--unshare-pid"},
		{"2.rootfs", "--ro-bind"},
		{"3.tmp", "/tmp"},
		{"4.overlays", "--overlay-src"},
		{"5.extra_writable", "--bind"},
		{"6.run", "/run"},
		{"7.dev", "--dev"},
		{"8.proc", "--proc"},
		{"9.env", "--unsetenv"},
		{"10.seccomp", "--seccomp"},
	}

	lastIdx := -1
	for _, s := range order {
		idx := indexOf(argv, s.match)
		if idx < 0 {
			t.Errorf("segment %s (%q) not found in argv:\n  %v", s.label, s.match, argv)
			continue
		}
		if idx <= lastIdx {
			t.Errorf("segment %s (%q) at %d: should be after index %d", s.label, s.match, idx, lastIdx)
		}
		lastIdx = idx
	}

	// setpriv must NOT appear in userns mode.
	assert.Equal(t, -1, indexOf(argv, "setpriv"), "setpriv must not appear in userns mode")
}

func TestBuildArgv_Validation(t *testing.T) {
	tests := []struct {
		name string
		opts WrapOptions
		want string
	}{
		{"empty_overlays", WrapOptions{}, "at least one overlay is required"},
		{"bad_profile", WrapOptions{Overlays: []OverlaySpec{{Path: "/ws", Mode: WorkspaceRW}}, Profile: "bogus"}, "unknown profile"},
		{"bad_mode", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{Path: "/ws", Mode: "bogus"}}}, "unknown overlay mode"},
		{"relative_overlay_path", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{Path: "rel/ws", Mode: WorkspaceRW}}}, "must be an absolute path"},
		{"duplicate_overlay_path", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{
			{Path: "/ws", Mode: WorkspaceRW},
			{Path: "/ws", Mode: WorkspaceRO},
		}}, "duplicate overlay path"},
		{"workdir_without_upperdir", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path: "/ws", Mode: WorkspaceOverlay, WorkDir: "/tmp/work",
		}}}, "workdir requires an upperdir"},
		{"shallow_upperdir", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path: "/ws", Mode: WorkspaceOverlay, UpperDir: "/foo/upper",
		}}}, "must live under an upper root"},
		{"upperdir_at_root", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path: "/ws", Mode: WorkspaceOverlay, UpperDir: "/upper",
		}}}, "must live under an upper root"},
		{"relative_upperdir", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path: "/ws", Mode: WorkspaceOverlay, UpperDir: "rel/session/upper",
		}}}, "must be an absolute path"},
		{"relative_workdir", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path: "/ws", Mode: WorkspaceOverlay, UpperDir: "/a/b/upper", WorkDir: "rel/work",
		}}}, "must be an absolute path"},
		{"upperdir_on_rw_mode", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path: "/ws", Mode: WorkspaceRW, UpperDir: "/a/b/upper",
		}}}, "upperdir/workdir apply only to overlay mode"},
		{"overlay_path_under_upper_root", WrapOptions{Profile: ProfileBalanced, Overlays: []OverlaySpec{{
			Path:     "/var/lib/execd/isolation/extra",
			Mode:     WorkspaceOverlay,
			UpperDir: "/var/lib/execd/isolation/abc/upper",
		}}}, "is shadowed by the upper-root tmpfs"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := buildArgv(tt.opts, "")
			if err == nil {
				t.Fatal("expected error, got nil")
			}
			if !strings.Contains(err.Error(), tt.want) {
				t.Errorf("error %q does not contain %q", err.Error(), tt.want)
			}
		})
	}
}

func TestMatchEnvPattern(t *testing.T) {
	tests := []struct {
		testName string
		envName  string
		pattern  string
		want     bool
	}{
		{"exact", "PATH", "PATH", true},
		{"suffix_wildcard_hit", "GITHUB_TOKEN", "*_TOKEN", true},
		{"suffix_wildcard_miss", "PATH", "*_TOKEN", false},
		{"prefix_wildcard_hit", "AWS_ACCESS_KEY_ID", "AWS_*", true},
		{"prefix_wildcard_miss", "PATH", "AWS_*", false},
		{"full_wildcard_hit", "MY_SECRET_KEY", "*SECRET*", true},
		{"full_wildcard_miss", "PATH", "*SECRET*", false},
		{"case_insensitive_exact", "PATH", "path", true},
		{"case_insensitive_pattern", "GITHUB_TOKEN", "*_token", true},
	}

	for _, tt := range tests {
		t.Run(tt.testName, func(t *testing.T) {
			got := matchEnvPattern(tt.envName, tt.pattern)
			if got != tt.want {
				t.Errorf("matchEnvPattern(%q, %q) = %v, want %v", tt.envName, tt.pattern, got, tt.want)
			}
		})
	}
}

func TestWrapWithArgv(t *testing.T) {
	cmd := exec.Command("bash", "-c", "echo hello")

	argv := []string{
		"--unshare-pid", "--ro-bind", "/", "/",
		"--tmpfs", "/tmp", "--tmpfs", "/run",
		"--dev", "/dev", "--proc", "/proc",
		"--bind", "/workspace", "/workspace",
		"--", "setpriv", "--reuid=1000", "--regid=1000", "--clear-groups",
	}

	wrapWithArgv(cmd, "/usr/bin/bwrap", argv)

	if cmd.Path != "/usr/bin/bwrap" {
		t.Errorf("Path = %q, want /usr/bin/bwrap", cmd.Path)
	}

	if len(cmd.Args) < 3 {
		t.Fatalf("too few args: %v", cmd.Args)
	}

	if cmd.Args[0] != "/usr/bin/bwrap" {
		t.Errorf("Args[0] = %q, want /usr/bin/bwrap", cmd.Args[0])
	}

	// Original command args should be at the end.
	n := len(cmd.Args)
	if cmd.Args[n-1] != "echo hello" || cmd.Args[n-2] != "-c" || cmd.Args[n-3] != "bash" {
		t.Errorf("original args not preserved at end: %v", cmd.Args)
	}
}

func TestProfile_Valid(t *testing.T) {
	if !ProfileStrict.Valid() {
		t.Error("strict should be valid")
	}
	if !ProfileBalanced.Valid() {
		t.Error("balanced should be valid")
	}
	if Profile("bogus").Valid() {
		t.Error("bogus should be invalid")
	}
}

func TestWorkspaceMode_Valid(t *testing.T) {
	for _, m := range []WorkspaceMode{WorkspaceRW, WorkspaceOverlay, WorkspaceRO} {
		if !m.Valid() {
			t.Errorf("%q should be valid", m)
		}
	}
	if WorkspaceMode("bogus").Valid() {
		t.Error("bogus should be invalid")
	}
}

func TestEnvMode_Valid(t *testing.T) {
	if !EnvModeDeny.Valid() {
		t.Error("deny should be valid")
	}
	if !EnvModeAllow.Valid() {
		t.Error("allow should be valid")
	}
	if EnvMode("bogus").Valid() {
		t.Error("bogus should be invalid")
	}
}

func TestUidMode_Valid(t *testing.T) {
	if !UidModeSetpriv.Valid() {
		t.Error("setpriv should be valid")
	}
	if !UidModeUserns.Valid() {
		t.Error("userns should be valid")
	}
	if UidMode("bogus").Valid() {
		t.Error("bogus should be invalid")
	}
}

func basicWrapOpts() WrapOptions {
	return WrapOptions{
		Profile:  ProfileBalanced,
		ShareNet: true,
		Overlays: []OverlaySpec{{Path: "/workspace", Mode: WorkspaceRW}},
	}
}

func indexOf(items []string, s string) int {
	for i, item := range items {
		if item == s {
			return i
		}
	}
	return -1
}

func TestBuildArgv_TmpDirHiding(t *testing.T) {
	t.Run("pairless_session_hides_derived_upper_root", func(t *testing.T) {
		// Pair-less sessions host /tmp without overlay uppers; the derived
		// root must still be hidden or ro-bind / leaks other sessions' dirs.
		opts := basicWrapOpts()
		opts.Overlays = []OverlaySpec{{Path: "/workspace", Mode: WorkspaceRW}}
		opts.TmpDir = "/var/lib/execd/isolation/abc/tmp"
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		s := strings.Join(argv, " ")
		if !strings.Contains(s, "--tmpfs /var/lib/execd/isolation") {
			t.Errorf("missing upper-root hiding tmpfs for the /tmp backing dir:\n  %s", s)
		}
	})

	t.Run("overlay_derived_and_tmp_derived_roots_dedupe", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.Overlays = []OverlaySpec{{
			Path:     "/workspace",
			Mode:     WorkspaceOverlay,
			UpperDir: "/var/lib/execd/isolation/abc/upper",
		}}
		opts.TmpDir = "/var/lib/execd/isolation/abc/tmp"
		argv, err := buildArgv(opts, "")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if got := strings.Count(strings.Join(argv, " "), "--tmpfs /var/lib/execd/isolation"); got != 1 {
			t.Errorf("hiding tmpfs count = %d, want 1 (deduped)", got)
		}
	})

	t.Run("shallow_tmp_dir_rejected", func(t *testing.T) {
		opts := basicWrapOpts()
		opts.TmpDir = "/x/tmp"
		_, err := buildArgv(opts, "")
		if err == nil || !strings.Contains(err.Error(), "upper root") {
			t.Fatalf("error = %v, want shallow upper-root rejection", err)
		}
	})
}

func TestBuildArgv_BindDestRootRejected(t *testing.T) {
	opts := basicWrapOpts()
	opts.Binds = []BindMount{{Source: "/data", Dest: "/"}}
	_, err := buildArgv(opts, "")
	if err == nil || !strings.Contains(err.Error(), "shadow the namespace root") {
		t.Fatalf("error = %v, want namespace-root shadow rejection", err)
	}
}
